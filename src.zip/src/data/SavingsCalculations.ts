import { type InputCardData } from './SavingsContext.tsx';

// --- Helpers ---

// Preprocess a card into a lookup map: { 'Current Balance': 15000, 'Interest Rate': 3, ... }
export const createFieldValueMap = (
  card: InputCardData,
): Map<string, number> => {
  const map = new Map<string, number>();
  for (const row of card.inputs) {
    for (const input of row) {
      const fieldParts = input.field.split(',');
      const fieldName = fieldParts[fieldParts.length - 1];
      map.set(fieldName, input.value ?? 0);
    }
  }
  return map;
};

// --- Calculations ---

// Projected balances (current vs proposed strategies)
export const calculateProjectedSavings = (
  cards: InputCardData[],
  timeframe: number,
): { current: number; proposed: number } => {
  if (cards.length < 2) return { current: 0, proposed: 0 };

  const [currentCard, proposedCard] = cards;
  const currentFields = createFieldValueMap(currentCard);
  const proposedFields = createFieldValueMap(proposedCard);

  const initialBalance = currentFields.get('Current Balance') ?? 0;
  const currentMonthlyContrib = currentFields.get('Monthly Contrib.') ?? 0;
  const currentInterestRate = (currentFields.get('Interest Rate') ?? 0) / 100;

  const proposedMonthlyContrib =
    proposedFields.get('New Monthly Contribution') ?? 0;
  const proposedInterestRate =
    (proposedFields.get('Target Interest Rate') ?? 0) / 100;

  // Calculate current savings strategy
  let currentBalance = initialBalance;
  for (let month = 1; month <= timeframe * 12; month++) {
    // Add monthly contribution
    currentBalance += currentMonthlyContrib;
    // Apply monthly interest (annual rate divided by 12)
    currentBalance *= 1 + currentInterestRate / 12;
  }

  // Calculate proposed savings strategy
  let proposedBalance = initialBalance;
  for (let month = 1; month <= timeframe * 12; month++) {
    // Add monthly contribution
    proposedBalance += proposedMonthlyContrib;
    // Apply monthly interest (annual rate divided by 12)
    proposedBalance *= 1 + proposedInterestRate / 12;
  }

  return {
    current: Math.round(currentBalance),
    proposed: Math.round(proposedBalance),
  };
};

// Calculate how long it will take to reach a goal
export const calculateTimeToGoal = (
  cards: InputCardData[],
  goalAmount: number,
): { currentMonths: number; proposedMonths: number } => {
  if (cards.length < 2) return { currentMonths: 0, proposedMonths: 0 };

  const [currentCard, proposedCard] = cards;
  const currentFields = createFieldValueMap(currentCard);
  const proposedFields = createFieldValueMap(proposedCard);

  const initialBalance = currentFields.get('Current Balance') ?? 0;
  const currentMonthlyContrib = currentFields.get('Monthly Contrib.') ?? 0;
  const currentInterestRate = (currentFields.get('Interest Rate') ?? 0) / 100;

  const proposedMonthlyContrib =
    proposedFields.get('New Monthly Contribution') ?? 0;
  const proposedInterestRate =
    (proposedFields.get('Target Interest Rate') ?? 0) / 100;

  // Calculate months needed for current strategy
  let currentBalance = initialBalance;
  let currentMonths = 0;
  while (currentBalance < goalAmount && currentMonths < 600) {
    // 50 years max
    currentBalance += currentMonthlyContrib;
    currentBalance *= 1 + currentInterestRate / 12;
    currentMonths++;
  }

  // Calculate months needed for proposed strategy
  let proposedBalance = initialBalance;
  let proposedMonths = 0;
  while (proposedBalance < goalAmount && proposedMonths < 600) {
    // 50 years max
    proposedBalance += proposedMonthlyContrib;
    proposedBalance *= 1 + proposedInterestRate / 12;
    proposedMonths++;
  }

  return {
    currentMonths: currentMonths >= 600 ? -1 : currentMonths, // -1 indicates goal not reached
    proposedMonths: proposedMonths >= 600 ? -1 : proposedMonths,
  };
};

// Calculate monthly difference in contributions
export const calculateMonthlySavingsDifference = (
  cards: InputCardData[],
): number => {
  if (cards.length < 2) return 0;

  const [currentCard, proposedCard] = cards;
  const currentFields = createFieldValueMap(currentCard);
  const proposedFields = createFieldValueMap(proposedCard);

  const currentMonthlyContrib = currentFields.get('Monthly Contrib.') ?? 0;
  const proposedMonthlyContrib =
    proposedFields.get('New Monthly Contribution') ?? 0;

  return proposedMonthlyContrib - currentMonthlyContrib;
};

// Calculate annual contributions
export const calculateAnnualContributions = (
  cards: InputCardData[],
): { current: number; proposed: number } => {
  if (cards.length < 3) return { current: 0, proposed: 0 };

  const additionalCard = cards[2];
  const additionalFields = createFieldValueMap(additionalCard);

  const currentContributions =
    additionalFields.get('Current Contributions') ?? 0;
  const proposedContributions =
    additionalFields.get('Proposed Contributions') ?? 0;

  return {
    current: currentContributions,
    proposed: proposedContributions,
  };
};

// Create dataset for bar graph with exponential growth
export const generateSavingsDataset = (
  cards: InputCardData[],
  timeframe: number,
) => {
  if (cards.length < 2) return [];

  const [currentCard, proposedCard] = cards;
  const currentFields = createFieldValueMap(currentCard);
  const proposedFields = createFieldValueMap(proposedCard);

  const initialBalance = currentFields.get('Current Balance') ?? 0;

  // Validate that the initial balance is valid
  if (initialBalance == null) {
    return []; // Exit if critical data is missing
  }

  const currentMonthlyContrib = currentFields.get('Monthly Contrib.') ?? 0;
  const currentInterestRate = (currentFields.get('Interest Rate') ?? 0) / 100;

  const proposedMonthlyContrib =
    proposedFields.get('New Monthly Contribution') ?? 0;
  const proposedInterestRate =
    (proposedFields.get('Target Interest Rate') ?? 0) / 100;

  let currentBalance = initialBalance;
  let proposedBalance = initialBalance;

  const dataset = [];

  // Track if proposed changes exist to conditionally display benefits
  const hasProposedChanges = proposedMonthlyContrib > 0;

  // Step through the years for the time frame
  dataset.push({
    year: 0,
    currentSituation: Math.round(initialBalance),
    proposedReturn: 0,
    proposedContributions: 0,
  });

  for (let year = 1; year <= timeframe; year++) {
    // Calculate for each month in the year
    for (let month = 1; month <= 12; month++) {
      // Current strategy
      currentBalance += currentMonthlyContrib;
      currentBalance *= 1 + currentInterestRate / 12;

      // Proposed strategy
      proposedBalance += proposedMonthlyContrib;
      proposedBalance *= 1 + proposedInterestRate / 12;
    }

    // Calculate the contribution and return components for visualization
    const currentContributions = currentMonthlyContrib * 12 * year;
    const proposedContributions = proposedMonthlyContrib * 12 * year;

    // Returns are the total minus the contributions and initial balance
    const currentReturns =
      currentBalance - initialBalance - currentContributions;
    const proposedReturns =
      proposedBalance - initialBalance - proposedContributions;

    dataset.push({
      year,
      currentSituation: Math.round(currentBalance), // Total current balance
      currentContributions: Math.round(currentContributions),
      currentReturn: Math.round(currentReturns),
      proposedSituation: hasProposedChanges ? Math.round(proposedBalance) : 0, // Total proposed balance
      proposedContributions: hasProposedChanges
        ? Math.round(proposedContributions)
        : 0,
      proposedReturn: hasProposedChanges ? Math.round(proposedReturns) : 0,
    });
  }

  return dataset;
};

// Calculate progress toward goal
export const calculateGoalProgress = (
  cards: InputCardData[],
): { currentProgress: number; proposedProgress: number } => {
  if (cards.length < 2) return { currentProgress: 0, proposedProgress: 0 };

  const [currentCard, proposedCard] = cards;
  const currentFields = createFieldValueMap(currentCard);
  const proposedFields = createFieldValueMap(proposedCard);

  // Get current progress value from input
  const currentProgress = currentFields.get('Savings Goal Progress') ?? 0;
  const proposedProgress = proposedFields.get('New Goal Progress') ?? 0;

  return {
    currentProgress,
    proposedProgress,
  };
};
