import React, {
  type ReactNode,
  createContext,
  useContext,
  useState,
} from 'react';

import { useTimeframe } from './TimeframeContext.tsx';

// Define input structure that matches your application's needs
export interface InputCardData {
  name: string;
  variant?: string;
  bg: string;
  inputs: Array<
    Array<{
      field: string;
      value: number;
      defaultValue: number;
    }>
  >;
  showCheckbox?: boolean;
  applyMaxSCG?: boolean;
}

// Define the structure of the context
export interface SuperannuationContextType {
  inputCards: InputCardData[];
  updateInputValue: (
    cardIndex: number,
    rowIndex: number,
    fieldIndex: number,
    newValue: number,
  ) => void;
  updateCheckboxValue: (cardIndex: number, checked: boolean) => void;
  resetToDefaults: () => void;
  saveInputs: () => void;
  timeframe: number;
  setTimeframe: (value: number) => void;
}

// Initial data structure based on your application
const initialInputCards: InputCardData[] = [
  {
    name: 'Charles Davies',
    variant: 'CURRENT',
    bg: '#edf2f7',
    inputs: [
      [
        { field: '$,Salary', value: 200000, defaultValue: 200000 },
        { field: '%,SCG', value: 11.5, defaultValue: 11.5 },
        { field: '%,Pay Increase', value: 3, defaultValue: 3 },
      ],
      [
        { field: '$,Balance', value: 200000, defaultValue: 200000 },
        { field: '%,Return', value: 5.5, defaultValue: 5.5 },
        { field: '$,Conc Contribution', value: 0, defaultValue: 0 },
      ],
    ],
    showCheckbox: true,
    applyMaxSCG: false,
  },
  {
    name: 'Charles Davies',
    variant: 'PROPOSED',
    bg: '#eafcb7',
    inputs: [
      [
        { field: '%,Return', value: 5.5, defaultValue: 5.5 },
        { field: '$,Conc Contribution', value: 10000, defaultValue: 10000 },
        { field: '$,Non Conc Contrib', value: 10000, defaultValue: 10000 },
      ],
      [
        { field: '$,Catch Up Conc. Con', value: 0, defaultValue: 0 },
        { field: '$,Gov Contribution', value: 0, defaultValue: 0 },
      ],
    ],
    showCheckbox: true,
    applyMaxSCG: false,
  },
  {
    name: 'Concessional Contributions',
    bg: '#b1d45a',
    inputs: [
      [
        { field: '$,Current Contributions', value: 23000, defaultValue: 23000 },
        {
          field: '$,Proposed Contributions',
          value: 0,
          defaultValue: 0,
        },
      ],
    ],
  },
];

// Create the context with a default value (with initial empty implementation)
export const SuperannuationContext = createContext<SuperannuationContextType>({
  inputCards: [],
  updateInputValue: () => {},
  updateCheckboxValue: () => {},
  resetToDefaults: () => {},
  saveInputs: () => {},
  timeframe: 30,
  setTimeframe: () => {},
});

// Provider component
export const SuperannuationProvider: React.FC<{ children: ReactNode }> = ({
  children,
}) => {
  const [inputCards, setInputCards] =
    useState<InputCardData[]>(initialInputCards);
  const { timeframe, setTimeframe } = useTimeframe();

  // Update a specific input value
  const updateInputValue = (
    cardIndex: number,
    rowIndex: number,
    fieldIndex: number,
    newValue: number,
  ) => {
    setInputCards((prevCards) => {
      const newCards = [...prevCards];
      if (
        newCards[cardIndex] &&
        newCards[cardIndex].inputs[rowIndex] &&
        newCards[cardIndex].inputs[rowIndex][fieldIndex]
      ) {
        newCards[cardIndex].inputs[rowIndex][fieldIndex].value = newValue;
      }
      return newCards;
    });
  };

  // Update checkbox value
  const updateCheckboxValue = (cardIndex: number, checked: boolean) => {
    setInputCards((prevCards) => {
      const newCards = [...prevCards];
      if (newCards[cardIndex]) {
        newCards[cardIndex].applyMaxSCG = checked;
      }
      return newCards;
    });
  };

  // Reset all inputs to their default values
  const resetToDefaults = () => {
    setInputCards((prevCards) => {
      return prevCards.map((card) => ({
        ...card,
        applyMaxSCG: false,
        inputs: card.inputs.map((row) =>
          row.map((input) => ({
            ...input,
            value: input.defaultValue,
          })),
        ),
      }));
    });
  };

  // Save current inputs (in a real app, this might save to local storage or backend)
  const saveInputs = () => {
    // In a real implementation, you might save to localStorage or a backend here
    console.log('Saving inputs:', inputCards);
    // For now, this is just a placeholder - the state is already saved in React state
  };

  const contextValue: SuperannuationContextType = {
    inputCards,
    updateInputValue,
    updateCheckboxValue,
    resetToDefaults,
    saveInputs,
    timeframe,
    setTimeframe,
  };

  return (
    <SuperannuationContext.Provider value={contextValue}>
      {children}
    </SuperannuationContext.Provider>
  );
};

// Custom hook to use the context
export const useSuperannuation = (): SuperannuationContextType => {
  return useContext(SuperannuationContext);
};
