// PortfolioCalculations.ts

import { type InputCardData } from './PortfolioContext.tsx';

// --- Helpers ---

export const createFieldValueMap = (
  card: InputCardData,
): Map<string, number> => {
  const map = new Map<string, number>();
  for (const row of card.inputs) {
    for (const input of row) {
      const fieldParts = input.field.split(',');
      const fieldName = fieldParts[fieldParts.length - 1];
      map.set(fieldName, input.value ?? 0);
    }
  }
  return map;
};

/**
 * Calculate future value with periodic contributions
 * @param principal - Initial investment
 * @param monthlyContribution - Monthly addition
 * @param annualRate - Annual interest rate (decimal)
 * @param months - Total months
 * @param compoundFrequency - Times per year interest is compounded
 */
export const calculateFutureValue = (
  principal: number,
  monthlyContribution: number,
  annualRate: number,
  months: number,
  compoundFrequency: number = 12,
): number => {
  // Convert annual rate to periodic rate
  const periodicRate = annualRate / compoundFrequency;
  const periodsPerMonth = compoundFrequency / 12;
  const totalPeriods = months * periodsPerMonth;

  let futureValue = principal;

  for (let period = 0; period < totalPeriods; period++) {
    // Add contribution (only add at the beginning of each month)
    if (period % periodsPerMonth === 0) {
      futureValue += monthlyContribution;
    }

    // Apply growth for the period
    futureValue *= 1 + periodicRate;
  }

  return futureValue;
};

/**
 * Calculate loan balance with regular repayments and interest
 * @param loanAmount - Initial loan balance
 * @param annualInterestRate - Annual interest rate (decimal)
 * @param monthlyPayment - Monthly repayment amount
 * @param months - Total months
 */
export const calculateLoanBalance = (
  loanAmount: number,
  annualInterestRate: number,
  monthlyPayment: number,
  months: number,
): number => {
  const monthlyRate = annualInterestRate / 12;
  let balance = loanAmount;

  for (let month = 0; month < months; month++) {
    // Add monthly interest
    balance *= 1 + monthlyRate;

    // Subtract payment
    balance -= monthlyPayment;

    // Ensure balance doesn't go below zero
    if (balance < 0) balance = 0;
  }

  return balance;
};

/**
 * Calculate maximum loan amount based on LVR and asset value
 * @param assetValue - Value of the asset
 * @param loanToValueRatio - LVR as percentage (e.g., 60 for 60%)
 */
export const calculateMaxLoanAmount = (
  assetValue: number,
  loanToValueRatio: number,
): number => {
  return assetValue * (loanToValueRatio / 100);
};

// --- Portfolio Calculations ---

export const calculateProjectedPortfolioValue = (
  cards: InputCardData[],
  timeframe: number,
): { current: number; proposed: number } => {
  if (cards.length < 3) return { current: 0, proposed: 0 };

  // Extract data from cards
  const ownFunds = cards[0];
  const borrowedFunds = cards[1];
  const superFunds = cards[2];

  const ownFields = createFieldValueMap(ownFunds);
  const borrowedFields = createFieldValueMap(borrowedFunds);
  const superFields = createFieldValueMap(superFunds);

  // Own funds values
  const ownLumpSum = ownFields.get('Lump Sum') ?? 0;
  const ownMonthly = ownFields.get('DCA Monthly') ?? 0;
  const ownReturn = ownFields.get('Expected Return') ?? 7; // Default 7% if not specified

  // Borrowed funds values
  const borrowedLumpSum = borrowedFields.get('Lump Sum') ?? 0;
  const borrowedMonthly = borrowedFields.get('DCA Monthly') ?? 0;
  const borrowedReturn = borrowedFields.get('Target Return') ?? 7; // Default 7%
  const loanInterestRate = borrowedFields.get('Loan Interest Rate') ?? 5.5; // Default 5.5%

  // Super values
  const annualContribution =
    superFields.get('Annual Concessional Contribution') ?? 27500;
  const recyclingPercentage =
    superFields.get('Recycling Allocation from Super') ?? 15;

  // Calculate current portfolio scenario
  const ownFutureValue = calculateFutureValue(
    ownLumpSum,
    ownMonthly,
    ownReturn / 100,
    timeframe * 12,
  );

  const borrowedFutureValue = calculateFutureValue(
    borrowedLumpSum,
    borrowedMonthly,
    borrowedReturn / 100,
    timeframe * 12,
  );

  const loanBalance = calculateLoanBalance(
    borrowedLumpSum,
    loanInterestRate / 100,
    borrowedMonthly,
    timeframe * 12,
  );

  const currentValue = ownFutureValue + borrowedFutureValue - loanBalance;

  // Calculate proposed scenario with super recycling
  // Monthly contribution from recycling super
  const monthlyRecycling =
    (annualContribution * recyclingPercentage) / 100 / 12;

  const proposedOwnFutureValue = calculateFutureValue(
    ownLumpSum,
    ownMonthly + monthlyRecycling,
    ownReturn / 100,
    timeframe * 12,
  );

  const proposedBorrowedFutureValue = calculateFutureValue(
    borrowedLumpSum,
    borrowedMonthly,
    borrowedReturn / 100,
    timeframe * 12,
  );

  // Assuming the recycling helps pay down loan faster
  const additionalLoanPayment = monthlyRecycling * 0.5; // Half of recycling goes to loan repayment
  const proposedLoanBalance = calculateLoanBalance(
    borrowedLumpSum,
    loanInterestRate / 100,
    borrowedMonthly + additionalLoanPayment,
    timeframe * 12,
  );

  const proposedValue =
    proposedOwnFutureValue + proposedBorrowedFutureValue - proposedLoanBalance;

  return {
    current: Math.round(currentValue),
    proposed: Math.round(proposedValue),
  };
};

export const calculateTimeToPortfolioGoal = (
  cards: InputCardData[],
  goalValue: number,
): { currentMonths: number; proposedMonths: number } => {
  if (cards.length < 3 || goalValue <= 0)
    return { currentMonths: 0, proposedMonths: 0 };

  // Extract data from cards
  const ownFunds = cards[0];
  const borrowedFunds = cards[1];
  const superFunds = cards[2];

  const ownFields = createFieldValueMap(ownFunds);
  const borrowedFields = createFieldValueMap(borrowedFunds);
  const superFields = createFieldValueMap(superFunds);

  // Own funds values
  const ownLumpSum = ownFields.get('Lump Sum') ?? 0;
  const ownMonthly = ownFields.get('DCA Monthly') ?? 0;
  const ownReturn = ownFields.get('Expected Return') ?? 7;

  // Borrowed funds values
  const borrowedLumpSum = borrowedFields.get('Lump Sum') ?? 0;
  const borrowedMonthly = borrowedFields.get('DCA Monthly') ?? 0;
  const borrowedReturn = borrowedFields.get('Target Return') ?? 7;
  const loanInterestRate = borrowedFields.get('Loan Interest Rate') ?? 5.5;

  // Super values
  const annualContribution =
    superFields.get('Annual Concessional Contribution') ?? 27500;
  const recyclingPercentage =
    superFields.get('Recycling Allocation from Super') ?? 15;

  // Calculate months to goal for current scenario
  let currentPortfolioValue = ownLumpSum + borrowedLumpSum;
  let currentLoanBalance = borrowedLumpSum;
  let currentMonths = 0;
  const currentMonthlyRate = (ownReturn + borrowedReturn) / 2 / 100 / 12;
  const loanMonthlyRate = loanInterestRate / 100 / 12;

  while (
    currentPortfolioValue - currentLoanBalance < goalValue &&
    currentMonths < 600
  ) {
    // Add monthly contributions
    currentPortfolioValue += ownMonthly + borrowedMonthly;

    // Calculate growth
    currentPortfolioValue *= 1 + currentMonthlyRate;

    // Update loan balance
    currentLoanBalance *= 1 + loanMonthlyRate;
    currentLoanBalance -= borrowedMonthly;
    if (currentLoanBalance < 0) currentLoanBalance = 0;

    currentMonths++;
  }

  // Calculate months to goal for proposed scenario with super recycling
  const monthlyRecycling =
    (annualContribution * recyclingPercentage) / 100 / 12;

  let proposedPortfolioValue = ownLumpSum + borrowedLumpSum;
  let proposedLoanBalance = borrowedLumpSum;
  let proposedMonths = 0;

  while (
    proposedPortfolioValue - proposedLoanBalance < goalValue &&
    proposedMonths < 600
  ) {
    // Add monthly contributions plus recycling
    proposedPortfolioValue += ownMonthly + borrowedMonthly + monthlyRecycling;

    // Calculate growth
    proposedPortfolioValue *= 1 + currentMonthlyRate;

    // Update loan balance with faster repayment
    proposedLoanBalance *= 1 + loanMonthlyRate;
    proposedLoanBalance -= borrowedMonthly + monthlyRecycling * 0.5;
    if (proposedLoanBalance < 0) proposedLoanBalance = 0;

    proposedMonths++;
  }

  return {
    currentMonths: currentMonths >= 600 ? -1 : currentMonths,
    proposedMonths: proposedMonths >= 600 ? -1 : proposedMonths,
  };
};

export const calculateMonthlyInvestmentDifference = (
  cards: InputCardData[],
): number => {
  if (cards.length < 3) return 0;

  const superFunds = cards[2];

  // Calculate super recycling monthly contribution
  const superFields = createFieldValueMap(superFunds);
  const annualContribution =
    superFields.get('Annual Concessional Contribution') ?? 27500;
  const recyclingPercentage =
    superFields.get('Recycling Allocation from Super') ?? 15;
  const monthlyRecycling =
    (annualContribution * recyclingPercentage) / 100 / 12;

  // The difference is how much more is invested monthly with recycling
  return monthlyRecycling;
};

export const calculateAnnualPortfolioContributions = (
  cards: InputCardData[],
): { current: number; proposed: number } => {
  if (cards.length < 3) return { current: 0, proposed: 0 };

  const ownFunds = cards[0];
  const borrowedFunds = cards[1];
  const superFunds = cards[2];

  const ownFields = createFieldValueMap(ownFunds);
  const borrowedFields = createFieldValueMap(borrowedFunds);
  const superFields = createFieldValueMap(superFunds);

  const ownMonthly = ownFields.get('DCA Monthly') ?? 0;
  const borrowedMonthly = borrowedFields.get('DCA Monthly') ?? 0;

  // Calculate current annual contributions
  const current = (ownMonthly + borrowedMonthly) * 12;

  // Calculate proposed contributions with super recycling
  const annualContribution =
    superFields.get('Annual Concessional Contribution') ?? 27500;
  const recyclingPercentage =
    superFields.get('Recycling Allocation from Super') ?? 15;
  const annualRecycling = (annualContribution * recyclingPercentage) / 100;

  const proposed = current + annualRecycling;

  return {
    current: Math.round(current),
    proposed: Math.round(proposed),
  };
};

export const generatePortfolioGrowthDataset = (
  cards: InputCardData[],
  timeframe: number,
) => {
  if (cards.length < 3) return [];

  // Extract data from cards
  const ownFunds = cards[0];
  const borrowedFunds = cards[1];
  const superFunds = cards[2];

  const ownFields = createFieldValueMap(ownFunds);
  const borrowedFields = createFieldValueMap(borrowedFunds);
  const superFields = createFieldValueMap(superFunds);

  // Own funds values
  const ownLumpSum = ownFields.get('Lump Sum') ?? 0;
  const ownMonthly = ownFields.get('DCA Monthly') ?? 0;
  const ownReturn = ownFields.get('Expected Return') ?? 7;

  // Borrowed funds values
  const borrowedLumpSum = borrowedFields.get('Lump Sum') ?? 0;
  const borrowedMonthly = borrowedFields.get('DCA Monthly') ?? 0;
  const borrowedReturn = borrowedFields.get('Target Return') ?? 7;
  const loanInterestRate = borrowedFields.get('Loan Interest Rate') ?? 5.5;

  // Super values
  const annualContribution =
    superFields.get('Annual Concessional Contribution') ?? 27500;
  const recyclingPercentage =
    superFields.get('Recycling Allocation from Super') ?? 15;
  const monthlyRecycling =
    (annualContribution * recyclingPercentage) / 100 / 12;

  // Initialize datasets
  const dataset = [
    {
      year: 0,
      currentSituation: Math.round(ownLumpSum + borrowedLumpSum),
      proposedSituation: Math.round(ownLumpSum + borrowedLumpSum),
      proposedContributions: 0,
      proposedReturn: 0,
      netEquity: Math.round(ownLumpSum), // Own funds minus loan
    },
  ];

  // Current scenario tracking
  let currentPortfolioValue = ownLumpSum + borrowedLumpSum;
  let currentLoanBalance = borrowedLumpSum;
  let currentTotalContributions = 0;

  // Proposed scenario tracking
  let proposedPortfolioValue = ownLumpSum + borrowedLumpSum;
  let proposedLoanBalance = borrowedLumpSum;
  let proposedTotalContributions = 0;

  // Calculate monthly rates
  const averageMonthlyRate = (ownReturn + borrowedReturn) / 2 / 100 / 12;
  const loanMonthlyRate = loanInterestRate / 100 / 12;

  for (let year = 1; year <= timeframe; year++) {
    // Track annual values
    let proposedYearStart = proposedPortfolioValue;

    for (let month = 1; month <= 12; month++) {
      // Current scenario monthly update
      currentPortfolioValue += ownMonthly + borrowedMonthly;
      currentTotalContributions += ownMonthly + borrowedMonthly;
      currentPortfolioValue *= 1 + averageMonthlyRate;

      // Update loan balance
      currentLoanBalance *= 1 + loanMonthlyRate;
      currentLoanBalance -= borrowedMonthly;
      if (currentLoanBalance < 0) currentLoanBalance = 0;

      // Proposed scenario monthly update
      proposedPortfolioValue += ownMonthly + borrowedMonthly + monthlyRecycling;
      proposedTotalContributions +=
        ownMonthly + borrowedMonthly + monthlyRecycling;
      proposedPortfolioValue *= 1 + averageMonthlyRate;

      // Update proposed loan balance with faster repayment
      proposedLoanBalance *= 1 + loanMonthlyRate;
      proposedLoanBalance -= borrowedMonthly + monthlyRecycling * 0.5;
      if (proposedLoanBalance < 0) proposedLoanBalance = 0;
    }

    // Calculate returns (growth minus contributions for the year)
    // const currentYearReturn =
    //   currentPortfolioValue -
    //   currentYearStart -
    //   (ownMonthly + borrowedMonthly) * 12;
    const proposedYearReturn =
      proposedPortfolioValue -
      proposedYearStart -
      (ownMonthly + borrowedMonthly + monthlyRecycling) * 12;

    dataset.push({
      year,
      currentSituation: Math.round(currentPortfolioValue - currentLoanBalance),
      proposedSituation: Math.round(
        proposedPortfolioValue - proposedLoanBalance,
      ),
      proposedContributions: Math.round(proposedTotalContributions),
      proposedReturn: Math.round(proposedYearReturn),
      netEquity: Math.round(proposedPortfolioValue - proposedLoanBalance),
    });
  }

  return dataset;
};

export const calculatePortfolioProgress = (
  cards: InputCardData[],
): { currentProgress: number; proposedProgress: number } => {
  if (cards.length < 3) return { currentProgress: 0, proposedProgress: 0 };

  const ownFunds = cards[0];
  const borrowedFunds = cards[1];
  const superFunds = cards[2];

  const ownFields = createFieldValueMap(ownFunds);
  const borrowedFields = createFieldValueMap(borrowedFunds);
  const superFields = createFieldValueMap(superFunds);

  // Calculate current portfolio value
  const ownLumpSum = ownFields.get('Lump Sum') ?? 0;
  const borrowedLumpSum = borrowedFields.get('Lump Sum') ?? 0;
  const borrowingLTV = borrowedFields.get('Current Loan to Value Ratio') ?? 60;

  // Estimate asset values based on LTV
  const assetValue = borrowedLumpSum / (borrowingLTV / 100);

  // Current progress is equity as percentage of total assets
  const currentEquity = ownLumpSum;
  const currentProgress = (currentEquity / (assetValue + ownLumpSum)) * 100;

  // Proposed progress includes super recycling benefit
  const annualContribution =
    superFields.get('Annual Concessional Contribution') ?? 27500;
  const recyclingPercentage =
    superFields.get('Recycling Allocation from Super') ?? 15;
  const annualRecycling = (annualContribution * recyclingPercentage) / 100;

  // Estimate 5-year impact of recycling (simplified)
  const fiveYearRecyclingImpact = annualRecycling * 5;
  const proposedEquity = currentEquity + fiveYearRecyclingImpact;
  const proposedProgress =
    (proposedEquity / (assetValue + ownLumpSum + fiveYearRecyclingImpact)) *
    100;

  return {
    currentProgress: Math.min(100, Math.round(currentProgress)),
    proposedProgress: Math.min(100, Math.round(proposedProgress)),
  };
};
