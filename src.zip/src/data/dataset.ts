// For years 0-60:
const calculateValues = (year: number) => {
  // Base investment grows at 7% annually (smaller exponential)
  const totalInvestment = 200 * Math.pow(1.07, year);

  // Net invest equals total investment
  const netInvest = totalInvestment;

  // Income is ~2.6% of investments (same growth rate)
  const incomeEstimate = 5.2 * Math.pow(1.07, year);

  return {
    year,
    totalInvestment: Math.round(totalInvestment),
    netInvest: Math.round(netInvest),
    incomeEstimate: parseFloat(incomeEstimate.toFixed(1)),
  };
};

// Generate dataset:
export const portfolioInvestments = Array.from({ length: 61 }, (_, i) =>
  calculateValues(i),
);

export function valueFormatter(value: number | null) {
  return `$${value}K`;
}
