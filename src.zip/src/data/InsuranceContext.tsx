import React, {
  type ReactNode,
  createContext,
  useContext,
  useState,
} from 'react';

import { useTimeframe } from './TimeframeContext.tsx';

// Define input structure that matches your insurance application's needs
export interface InputCardData {
  name: string;
  variant?: string;
  bg: string;
  inputs: Array<
    Array<{
      field: string;
      value: number;
      defaultValue: number;
    }>
  >;
  showCheckbox?: boolean;
  applyMaxCoverage?: boolean;
}

// Define the structure of the context
export interface InsuranceContextType {
  inputCards: InputCardData[];
  updateInputValue: (
    cardIndex: number,
    rowIndex: number,
    fieldIndex: number,
    newValue: number,
  ) => void;
  updateCheckboxValue: (cardIndex: number, checked: boolean) => void;
  resetToDefaults: () => void;
  saveInputs: () => void;
  timeframe: number;
  setTimeframe: (value: number) => void;
}

// Initial data structure based on your insurance application
const initialInputCards: InputCardData[] = [
  {
    name: 'Charles Davies',
    variant: 'CURRENT',
    bg: '#edf2f7',
    inputs: [
      [
        { field: '$,Annual Premium', value: 2400, defaultValue: 2400 },
        { field: '$,Coverage Amount', value: 500000, defaultValue: 500000 },
        { field: '%,Premium Increase', value: 3, defaultValue: 3 },
      ],
      [
        { field: '$,Deductible', value: 1000, defaultValue: 1000 },
        { field: '%,Claim Probability', value: 5, defaultValue: 5 },
        { field: '$,Additional Riders', value: 300, defaultValue: 300 },
      ],
    ],
    showCheckbox: true,
    applyMaxCoverage: false,
  },
  {
    name: 'Charles Davies',
    variant: 'PROPOSED',
    bg: '#eafcb7',
    inputs: [
      [
        { field: '$,Coverage Amount', value: 750000, defaultValue: 750000 },
        { field: '$,Annual Premium', value: 3200, defaultValue: 3200 },
        { field: '$,Deductible', value: 500, defaultValue: 500 },
      ],
      [
        { field: '$,Additional Riders', value: 500, defaultValue: 500 },
        { field: '%,Premium Discount', value: 10, defaultValue: 10 },
      ],
    ],
    showCheckbox: true,
    applyMaxCoverage: false,
  },
  {
    name: 'Coverage Analysis',
    bg: '#b1d45a',
    inputs: [
      [
        {
          field: '$,Current Out-of-Pocket Max',
          value: 5000,
          defaultValue: 5000,
        },
        {
          field: '$,Proposed Out-of-Pocket Max',
          value: 3000,
          defaultValue: 3000,
        },
      ],
    ],
  },
];

// Create the context with a default value (with initial empty implementation)
export const InsuranceContext = createContext<InsuranceContextType>({
  inputCards: [],
  updateInputValue: () => {},
  updateCheckboxValue: () => {},
  resetToDefaults: () => {},
  saveInputs: () => {},
  timeframe: 60,
  setTimeframe: () => {},
});

// Provider component
export const InsuranceProvider: React.FC<{ children: ReactNode }> = ({
  children,
}) => {
  const [inputCards, setInputCards] =
    useState<InputCardData[]>(initialInputCards);
  const { timeframe, setTimeframe } = useTimeframe();

  // Update a specific input value
  const updateInputValue = (
    cardIndex: number,
    rowIndex: number,
    fieldIndex: number,
    newValue: number,
  ) => {
    setInputCards((prevCards) => {
      const newCards = [...prevCards];
      if (
        newCards[cardIndex] &&
        newCards[cardIndex].inputs[rowIndex] &&
        newCards[cardIndex].inputs[rowIndex][fieldIndex]
      ) {
        newCards[cardIndex].inputs[rowIndex][fieldIndex].value = newValue;
      }
      return newCards;
    });
  };

  // Update checkbox value
  const updateCheckboxValue = (cardIndex: number, checked: boolean) => {
    setInputCards((prevCards) => {
      const newCards = [...prevCards];
      if (newCards[cardIndex]) {
        newCards[cardIndex].applyMaxCoverage = checked;
      }
      return newCards;
    });
  };

  // Reset all inputs to their default values
  // const resetToDefaults = () => {
  //   setInputCards((prevCards) => {
  //     return prevCards.map((card) => ({
  //       ...card,
  //       applyMaxCoverage: false,
  //       inputs: card.inputs.map((row) =>
  //         row.map((input) => ({
  //           ...input,
  //           value: input.defaultValue,
  //         })),
  //       ),
  //     }));
  //   });
  // };

  const resetToDefaults = () => {
    // Create a deep copy of the initial state
    setInputCards((prevCards) => {
      return prevCards.map((card) => ({
        ...card,
        applyMaxCoverage: false,
        inputs: card.inputs.map((row) =>
          row.map((input) => ({
            ...input,
            value: input.defaultValue,
          })),
        ),
      }));
    });
  };

  // Save current inputs (in a real app, this might save to local storage or backend)
  const saveInputs = () => {
    // In a real implementation, you might save to localStorage or a backend here
    console.log('Saving inputs:', inputCards);
    // For now, this is just a placeholder - the state is already saved in React state
  };

  const contextValue: InsuranceContextType = {
    inputCards,
    updateInputValue,
    updateCheckboxValue,
    resetToDefaults,
    saveInputs,
    timeframe,
    setTimeframe,
  };

  return (
    <InsuranceContext.Provider value={contextValue}>
      {children}
    </InsuranceContext.Provider>
  );
};

// Custom hook to use the context
export const useInsurance = (): InsuranceContextType => {
  return useContext(InsuranceContext);
};
