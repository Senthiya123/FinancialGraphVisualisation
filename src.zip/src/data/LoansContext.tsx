import React, {
  type ReactNode,
  createContext,
  useContext,
  useState,
} from 'react';

import { useTimeframe } from './TimeframeContext.tsx';

// Define input structure that matches your application's needs
export interface InputCardData {
  name: string;
  variant?: string;
  bg: string;
  inputs: Array<
    Array<{
      field: string;
      value: number;
      defaultValue: number;
    }>
  >;
  showCheckbox?: boolean;
}

// Define the structure of the context
export interface LoansContextType {
  inputCards: InputCardData[];
  updateInputValue: (
    cardIndex: number,
    rowIndex: number,
    fieldIndex: number,
    newValue: number,
  ) => void;
  resetToDefaults: () => void;
  saveInputs: () => void;
  timeframe: number;
  setTimeframe: (value: number) => void;
}

// Initial data structure based on your application
const initialInputCards: InputCardData[] = [
  {
    name: 'Charles Davies',
    variant: 'CURRENT LOANS',
    bg: '#edf2f7',
    inputs: [
      [
        { field: '$,Loan Amount', value: 500000, defaultValue: 500000 },
        { field: '%,Interest Rate', value: 4.5, defaultValue: 4.5 },
        { field: 'Years,Loan Term', value: 30, defaultValue: 30 },
      ],
      [
        { field: '$,Monthly Repayment', value: 2533, defaultValue: 2533 },
        {
          field: '%,Offset Account Balance',
          value: 10000,
          defaultValue: 10000,
        },
      ],
    ],
  },
  {
    name: 'Charles Davies',
    variant: 'PROPOSED LOANS',
    bg: '#eafcb7',
    inputs: [
      [
        { field: '$,Loan Amount', value: 450000, defaultValue: 450000 },
        { field: '%,Interest Rate', value: 4.1, defaultValue: 4.1 },
        { field: 'Years,Loan Term', value: 25, defaultValue: 25 },
      ],
      [
        { field: '$,Monthly Repayment', value: 2400, defaultValue: 2400 },
        {
          field: '%,Offset Account Balance',
          value: 20000,
          defaultValue: 20000,
        },
      ],
    ],
  },
  {
    name: 'Extra Repayments',
    bg: '#b1d45a',
    inputs: [
      [
        { field: '$,Current Extra Repayments', value: 200, defaultValue: 200 },
        { field: '$,Proposed Extra Repayments', value: 500, defaultValue: 500 },
      ],
    ],
  },
];

// Create the context with a default value (with initial empty implementation)
export const LoansContext = createContext<LoansContextType>({
  inputCards: [],
  updateInputValue: () => {},
  resetToDefaults: () => {},
  saveInputs: () => {},
  timeframe: 30,
  setTimeframe: () => {},
});

// Provider component
export const LoansProvider: React.FC<{ children: ReactNode }> = ({
  children,
}) => {
  const [inputCards, setInputCards] =
    useState<InputCardData[]>(initialInputCards);
  const { timeframe, setTimeframe } = useTimeframe();

  // Update a specific input value
  const updateInputValue = (
    cardIndex: number,
    rowIndex: number,
    fieldIndex: number,
    newValue: number,
  ) => {
    setInputCards((prevCards) => {
      const newCards = [...prevCards];
      if (
        newCards[cardIndex] &&
        newCards[cardIndex].inputs[rowIndex] &&
        newCards[cardIndex].inputs[rowIndex][fieldIndex]
      ) {
        newCards[cardIndex].inputs[rowIndex][fieldIndex].value = newValue;
      }
      return newCards;
    });
  };

  // Reset all inputs to their default values
  const resetToDefaults = () => {
    setInputCards((prevCards) => {
      return prevCards.map((card) => ({
        ...card,
        checked: false,
        inputs: card.inputs.map((row) =>
          row.map((input) => ({
            ...input,
            value: input.defaultValue,
          })),
        ),
      }));
    });
  };

  // Save current inputs (in a real app, this might save to local storage or backend)
  const saveInputs = () => {
    // In a real implementation, you might save to localStorage or a backend here
    console.log('Saving inputs:', inputCards);
    // For now, this is just a placeholder - the state is already saved in React state
  };

  const contextValue: LoansContextType = {
    inputCards,
    updateInputValue,
    resetToDefaults,
    saveInputs,
    timeframe,
    setTimeframe,
  };

  return (
    <LoansContext.Provider value={contextValue}>
      {children}
    </LoansContext.Provider>
  );
};

// Custom hook to use the context
export const useLoans = (): LoansContextType => {
  return useContext(LoansContext);
};
