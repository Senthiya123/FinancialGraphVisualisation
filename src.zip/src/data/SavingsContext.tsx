import React, {
  type ReactNode,
  createContext,
  useContext,
  useState,
} from 'react';

import { useTimeframe } from './TimeframeContext.tsx';

// Define input structure that matches your application's needs
export interface InputCardData {
  name: string;
  variant?: string;
  bg: string;
  inputs: Array<
    Array<{
      field: string;
      value: number;
      defaultValue: number;
    }>
  >;
  showCheckbox?: boolean;
}

// Define the structure of the context
export interface SavingsContextType {
  inputCards: InputCardData[];
  updateInputValue: (
    cardIndex: number,
    rowIndex: number,
    fieldIndex: number,
    newValue: number,
  ) => void;
  resetToDefaults: () => void;
  saveInputs: () => void;
  timeframe: number;
  setTimeframe: (value: number) => void;
}

// Initial data structure based on your application
const initialInputCards: InputCardData[] = [
  {
    name: 'Charles Davies',
    variant: 'CURRENT SAVINGS',
    bg: '#edf2f7',
    inputs: [
      [
        { field: '$,Current Balance', value: 15000, defaultValue: 15000 },
        { field: '$,Monthly Contrib.', value: 500, defaultValue: 500 },
        { field: '%,Interest Rate', value: 3, defaultValue: 3 },
      ],
      [
        { field: '%,Savings Goal Progress', value: 30, defaultValue: 30 },
        { field: 'Years,Time Horizon', value: 5, defaultValue: 5 },
      ],
    ],
    showCheckbox: true,
  },
  {
    name: 'Charles Davies',
    variant: 'PROPOSED SAVINGS',
    bg: '#eafcb7',
    inputs: [
      [
        { field: '$,New Monthly Contribution', value: 750, defaultValue: 750 },
        { field: '%,Target Interest Rate', value: 4, defaultValue: 4 },
      ],
      [
        { field: '%,New Goal Progress', value: 45, defaultValue: 45 },
        { field: 'Years,New Time Horizon', value: 4, defaultValue: 4 },
      ],
    ],
    showCheckbox: true,
  },
  {
    name: 'Additional Contributions',
    bg: '#b1d45a',
    inputs: [
      [
        { field: '$,Current Contributions', value: 6000, defaultValue: 6000 },
        { field: '$,Proposed Contributions', value: 9000, defaultValue: 9000 },
      ],
    ],
  },
];

// Create the context with a default value (with initial empty implementation)
export const SavingsContext = createContext<SavingsContextType>({
  inputCards: [],
  updateInputValue: () => {},
  resetToDefaults: () => {},
  saveInputs: () => {},
  timeframe: 30,
  setTimeframe: () => {},
});

// Provider component
export const SavingsProvider: React.FC<{ children: ReactNode }> = ({
  children,
}) => {
  const [inputCards, setInputCards] =
    useState<InputCardData[]>(initialInputCards);
  const { timeframe, setTimeframe } = useTimeframe();

  // Update a specific input value
  const updateInputValue = (
    cardIndex: number,
    rowIndex: number,
    fieldIndex: number,
    newValue: number,
  ) => {
    setInputCards((prevCards) => {
      const newCards = [...prevCards];
      if (
        newCards[cardIndex] &&
        newCards[cardIndex].inputs[rowIndex] &&
        newCards[cardIndex].inputs[rowIndex][fieldIndex]
      ) {
        newCards[cardIndex].inputs[rowIndex][fieldIndex].value = newValue;
      }
      return newCards;
    });
  };

  // Reset all inputs to their default values
  const resetToDefaults = () => {
    setInputCards((prevCards) => {
      return prevCards.map((card) => ({
        ...card,
        checked: false,
        inputs: card.inputs.map((row) =>
          row.map((input) => ({
            ...input,
            value: input.defaultValue,
          })),
        ),
      }));
    });
  };

  // Save current inputs (in a real app, this might save to local storage or backend)
  const saveInputs = () => {
    // In a real implementation, you might save to localStorage or a backend here
    console.log('Saving inputs:', inputCards);
    // For now, this is just a placeholder - the state is already saved in React state
  };

  const contextValue: SavingsContextType = {
    inputCards,
    updateInputValue,
    resetToDefaults,
    saveInputs,
    timeframe,
    setTimeframe,
  };

  return (
    <SavingsContext.Provider value={contextValue}>
      {children}
    </SavingsContext.Provider>
  );
};

// Custom hook to use the context
export const useSavings = (): SavingsContextType => {
  return useContext(SavingsContext);
};
