// src/data/TimeframeContext.tsx

import { type ReactNode, createContext, useContext, useState } from 'react';

// 1. Define context type
interface TimeframeContextType {
  timeframe: number;
  setTimeframe: (value: number) => void;
}

// 2. Create context with undefined initial value
const TimeframeContext = createContext<TimeframeContextType | undefined>(
  undefined,
);

// 3. Create provider
export const TimeframeProvider = ({ children }: { children: ReactNode }) => {
  const [timeframe, setTimeframe] = useState<number>(30);

  const value: TimeframeContextType = {
    timeframe,
    setTimeframe,
  };

  return (
    <TimeframeContext.Provider value={value}>
      {children}
    </TimeframeContext.Provider>
  );
};

// 4. Custom hook to consume the context
export const useTimeframe = (): TimeframeContextType => {
  const context = useContext(TimeframeContext);
  if (!context) {
    throw new Error('useTimeframe must be used within a TimeframeProvider');
  }
  return context;
};
