import { type InputCardData } from './SuperannuationContext.tsx';

// --- Helpers ---

// Preprocess a card into a lookup map: { 'Balance': 100000, 'Return': 7, ... }
export const createFieldValueMap = (
  card: InputCardData,
): Map<string, number> => {
  const map = new Map<string, number>();
  for (const row of card.inputs) {
    for (const input of row) {
      const fieldParts = input.field.split(',');
      const fieldName = fieldParts[fieldParts.length - 1];
      map.set(fieldName, input.value ?? 0);
    }
  }
  return map;
};

// --- Calculations ---

// Projected balances (current vs proposed strategies)
export const calculateProjectedBalance = (
  cards: InputCardData[],
  timeframe: number,
): { current: number; proposed: number } => {
  if (cards.length < 2) return { current: 0, proposed: 0 };

  const [currentCard, proposedCard] = cards;
  const currentFields = createFieldValueMap(currentCard);
  const proposedFields = createFieldValueMap(proposedCard);

  const initialBalance = currentFields.get('Balance') ?? 0;
  const currentReturnRate = (currentFields.get('Return') ?? 0) / 100;
  const salary = currentFields.get('Salary') ?? 0;
  const sgcRate = (currentFields.get('SCG') ?? 0) / 100;
  const payIncreaseRate = (currentFields.get('Pay Increase') ?? 0) / 100;

  const currentConc = currentFields.get('Conc Contribution') ?? 0;

  const proposedReturnRate = ((proposedFields.get('Return') ?? 0) / 100) - currentReturnRate;
  const proposedConc = proposedFields.get('Conc Contribution') ?? 0;
  const proposedNonConc = proposedFields.get('Non Conc Contrib') ?? 0;
  const catchUp = proposedFields.get('Catch Up Conc. Con') ?? 0;
  const govContribution = proposedFields.get('Gov Contribution') ?? 0;

  let currentBalance = initialBalance;
  let proposedBalance = initialBalance;
  let currentSalary = salary;
  let proposedSalary = salary;

  for (let year = 1; year <= timeframe; year++) {
    // Current strategy calculations
    const currentEmployerContrib = currentSalary * sgcRate;
    currentBalance += currentEmployerContrib + currentConc;
    currentBalance *= 1 + currentReturnRate;
    currentSalary *= 1 + payIncreaseRate;

    // Proposed strategy calculations
    const proposedEmployerContrib = proposedSalary * sgcRate;
    proposedBalance +=
      proposedEmployerContrib +
      proposedConc +
      proposedNonConc +
      catchUp +
      govContribution;
    proposedBalance *= 1 + proposedReturnRate;
    proposedSalary *= 1 + payIncreaseRate;
  }

  return {
    current: Math.round(currentBalance),
    proposed: Math.round(proposedBalance),
  };
};

// Annual income estimate (using 5% drawdown rate for a more realistic retirement income)
export const calculateAnnualIncome = (
  projectedBalance: number,
  drawdownRate = 0.05,
): number => {
  return Math.round(projectedBalance * drawdownRate);
};

// Weekly cost of proposed strategy compared to current
export const calculateWeeklyCost = (cards: InputCardData[]): number => {
  if (cards.length < 2) return 0;

  const [currentCard, proposedCard] = cards;
  const currentFields = createFieldValueMap(currentCard);
  const proposedFields = createFieldValueMap(proposedCard);

  const currentConc = currentFields.get('Conc Contribution') ?? 0;
  const proposedConc = proposedFields.get('Conc Contribution') ?? 0;
  const proposedNonConc = proposedFields.get('Non Conc Contrib') ?? 0;
  const catchUp = proposedFields.get('Catch Up Conc. Con') ?? 0;

  // Calculate the total additional annual contribution
  const additionalAnnual =
    proposedConc + proposedNonConc + catchUp - currentConc;

  // Convert to weekly cost
  return Math.round(additionalAnnual / 52);
};

// Create dataset for bar graph
export const generateRealDataset = (
  cards: InputCardData[],
  timeframe: number,
) => {
  if (cards.length < 2) return [];

  const [currentCard, proposedCard] = cards;
  const currentFields = createFieldValueMap(currentCard);
  const proposedFields = createFieldValueMap(proposedCard);

  const initialBalance = currentFields.get('Balance') ?? 0;
  const salary = currentFields.get('Salary') ?? 0;

  // Exit if critical data is missing
  if (initialBalance === 0 || salary === 0) {
    return [];
  }

  const currentReturnRate = (currentFields.get('Return') ?? 0) / 100;
  const proposedReturnRate = (proposedFields.get('Return') ?? 0) / 100;
  const sgcRate = (currentFields.get('SCG') ?? 0) / 100;
  const payIncreaseRate = (currentFields.get('Pay Increase') ?? 0) / 100;
  const proposedConc = proposedFields.get('Conc Contribution') ?? 0;
  const proposedNonConc = proposedFields.get('Non Conc Contrib') ?? 0;
  const catchUp = proposedFields.get('Catch Up Conc. Con') ?? 0;
  const govContribution = proposedFields.get('Gov Contribution') ?? 0;

  let currentBalance = initialBalance;
  let proposedBalance = initialBalance;
  let currentSalary = salary;
  let proposedSalary = salary;

  // For calculating the contributions accumulation
  let totalConcContributions = 0;
  let totalNonConcContributions = 0;

  const dataset = [];

  // Check if there are any proposed changes
  const hasProposedChanges =
    proposedConc > 0 ||
    proposedNonConc > 0 ||
    catchUp > 0 ||
    govContribution > 0 ||
    proposedReturnRate > currentReturnRate;

  // Generate data for each year
  for (let year = 0; year <= timeframe; year++) {
    if (year === 0) {
      // Initial year - just show the starting balance
      dataset.push({
        year,
        currentSituation: Math.round(initialBalance),
        proposedReturn: 0,
        proposedConc: 0,
        proposedNonConc: 0,
      });
    } else {
      // Calculate employer contributions based on salary
      const currentEmployerContrib = currentSalary * sgcRate;
      const proposedEmployerContrib = proposedSalary * sgcRate;

      // Update current strategy balances
      currentBalance +=
        currentEmployerContrib + (currentFields.get('Conc Contribution') ?? 0);
      currentBalance *= 1 + currentReturnRate;

      // Update proposed strategy components
      const yearlyProposedConc = proposedConc + catchUp;
      const yearlyProposedNonConc = proposedNonConc;

      totalConcContributions += yearlyProposedConc;
      totalNonConcContributions += yearlyProposedNonConc;

      // Calculate proposed balance with all contributions
      proposedBalance +=
        proposedEmployerContrib +
        yearlyProposedConc +
        yearlyProposedNonConc +
        govContribution;
      proposedBalance *= 1 + proposedReturnRate;

      // Calculate the return component (difference between total balance and contributions)
      const totalContributions =
        initialBalance + totalConcContributions + totalNonConcContributions;
      const returnComponent = proposedBalance - totalContributions;

      // Add data point for this year
      dataset.push({
        year,
        currentSituation: Math.round(currentBalance),
        proposedReturn: hasProposedChanges
          ? Math.round(Math.max(0, returnComponent))
          : 0,
        proposedConc: hasProposedChanges
          ? Math.round(totalConcContributions)
          : 0,
        proposedNonConc: hasProposedChanges
          ? Math.round(totalNonConcContributions)
          : 0,
      });

      // Update salaries for next year
      currentSalary *= 1 + payIncreaseRate;
      proposedSalary *= 1 + payIncreaseRate;
    }
  }

  return dataset;
};
