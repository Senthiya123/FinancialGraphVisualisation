// AllProviders.tsx
import { type ReactNode } from 'react';

import { InsuranceProvider } from './InsuranceContext.tsx';
import { LoansProvider } from './LoansContext.tsx';
import { PortfolioProvider } from './PortfolioContext.tsx';
import { SavingsProvider } from './SavingsContext.tsx';
import { SuperannuationProvider } from './SuperannuationContext.tsx';

interface AllProvidersProps {
  children: ReactNode;
}

export const AllProviders = ({ children }: AllProvidersProps) => {
  return (
    <SuperannuationProvider>
      <InsuranceProvider>
        <LoansProvider>
          <SavingsProvider>
            <PortfolioProvider>{children}</PortfolioProvider>
          </SavingsProvider>
        </LoansProvider>
      </InsuranceProvider>
    </SuperannuationProvider>
  );
};
