// Updated LoansCalculations.ts

import type { InputCardData } from './LoansContext';

// Utility: Create a map of field names to values for quick access
export const createFieldValueMap = (
  card: InputCardData,
): Map<string, number> => {
  const map = new Map<string, number>();
  for (const row of card.inputs) {
    for (const input of row) {
      // Extract the actual field name (after the symbol and comma)
      const fieldName = input.field.split(',').pop();
      if (fieldName) {
        map.set(fieldName.trim(), input.value ?? 0);
      }
    }
  }
  return map;
};

// Projection: Generate loan balance data over a given timeframe
export const calculateProjectedLoans = (
  cards: InputCardData[],
  timeframe: number,
) => {
  if (cards.length < 2) return [];

  const [currentCard, proposedCard] = cards;
  const currentFields = createFieldValueMap(currentCard);
  const proposedFields = createFieldValueMap(proposedCard);

  // Extract the required values using the field names that actually exist in the data
  const initialLoanAmount = currentFields.get('Loan Amount') ?? 0;
  if (initialLoanAmount === 0) return [];

  const currentMonthlyRepayment = currentFields.get('Monthly Repayment') ?? 0;
  const currentInterestRate = (currentFields.get('Interest Rate') ?? 0) / 100;
  const currentOffsetBalance = currentFields.get('Offset Account Balance') ?? 0;

  const proposedMonthlyRepayment = proposedFields.get('Monthly Repayment') ?? 0;
  const proposedInterestRate = (proposedFields.get('Interest Rate') ?? 0) / 100;
  const proposedOffsetBalance =
    proposedFields.get('Offset Account Balance') ?? 0;

  // Get extra repayments if the third card exists
  let currentExtraRepayment = 0;
  let proposedExtraRepayment = 0;
  if (cards.length > 2) {
    const extraRepaymentCard = cards[2];
    const extraFields = createFieldValueMap(extraRepaymentCard);
    currentExtraRepayment = extraFields.get('Current Extra Repayments') ?? 0;
    proposedExtraRepayment = extraFields.get('Proposed Extra Repayments') ?? 0;
  }

  // Calculate effective loan amounts (after offset account)
  let currentBalance = Math.max(initialLoanAmount - currentOffsetBalance, 0);
  let proposedBalance = Math.max(
    proposedFields.get('Loan Amount') ??
      initialLoanAmount - proposedOffsetBalance,
    0,
  );

  const totalCurrentMonthlyPayment =
    currentMonthlyRepayment + currentExtraRepayment;
  const totalProposedMonthlyPayment =
    proposedMonthlyRepayment + proposedExtraRepayment;

  const dataset = [
    {
      year: 0,
      currentSituation: Math.round(currentBalance),
      proposedSituation: Math.round(proposedBalance),
    },
  ];

  for (let year = 1; year <= timeframe; year++) {
    for (let month = 0; month < 12; month++) {
      // Current scenario
      if (currentBalance > 0) {
        const monthlyInterest = currentBalance * (currentInterestRate / 12);
        currentBalance = Math.max(
          currentBalance + monthlyInterest - totalCurrentMonthlyPayment,
          0,
        );
      }

      // Proposed scenario
      if (proposedBalance > 0) {
        const monthlyInterest = proposedBalance * (proposedInterestRate / 12);
        proposedBalance = Math.max(
          proposedBalance + monthlyInterest - totalProposedMonthlyPayment,
          0,
        );
      }
    }

    dataset.push({
      year,
      currentSituation: Math.round(currentBalance),
      proposedSituation: Math.round(proposedBalance),
    });
  }

  return dataset;
};

// Summary Calculations:

export const calculateTotalLoanAmount = (cards: InputCardData[]) => {
  if (!cards.length) return 0;
  const fields = createFieldValueMap(cards[0]);
  return fields.get('Loan Amount') ?? 0;
};

export const calculateMonthlyRepaymentChange = (cards: InputCardData[]) => {
  if (cards.length < 2) return 0;

  const current = createFieldValueMap(cards[0]);
  const proposed = createFieldValueMap(cards[1]);

  // Get extra repayments
  let currentExtraRepayment = 0;
  let proposedExtraRepayment = 0;
  if (cards.length > 2) {
    const extraFields = createFieldValueMap(cards[2]);
    currentExtraRepayment = extraFields.get('Current Extra Repayments') ?? 0;
    proposedExtraRepayment = extraFields.get('Proposed Extra Repayments') ?? 0;
  }

  const currentTotalRepayment =
    (current.get('Monthly Repayment') ?? 0) + currentExtraRepayment;
  const proposedTotalRepayment =
    (proposed.get('Monthly Repayment') ?? 0) + proposedExtraRepayment;

  return proposedTotalRepayment - currentTotalRepayment;
};

export const calculateInterestSaved = (cards: InputCardData[]) => {
  if (cards.length < 2) return 0;

  const current = createFieldValueMap(cards[0]);
  const proposed = createFieldValueMap(cards[1]);

  // Get extra repayments
  let currentExtraRepayment = 0;
  let proposedExtraRepayment = 0;
  if (cards.length > 2) {
    const extraFields = createFieldValueMap(cards[2]);
    currentExtraRepayment = extraFields.get('Current Extra Repayments') ?? 0;
    proposedExtraRepayment = extraFields.get('Proposed Extra Repayments') ?? 0;
  }

  const currentBalance = current.get('Loan Amount') ?? 0;
  const proposedBalance = proposed.get('Loan Amount') ?? 0;

  const currentOffsetBalance = current.get('Offset Account Balance') ?? 0;
  const proposedOffsetBalance = proposed.get('Offset Account Balance') ?? 0;

  const currentRate = (current.get('Interest Rate') ?? 0) / 100;
  const proposedRate = (proposed.get('Interest Rate') ?? 0) / 100;

  const currentRepayment =
    (current.get('Monthly Repayment') ?? 0) + currentExtraRepayment;
  const proposedRepayment =
    (proposed.get('Monthly Repayment') ?? 0) + proposedExtraRepayment;

  // Calculate effective loan amounts (after offset account)
  let currentBal = Math.max(currentBalance - currentOffsetBalance, 0);
  let proposedBal = Math.max(proposedBalance - proposedOffsetBalance, 0);

  let currentInterest = 0;
  let proposedInterest = 0;

  for (let month = 0; month < 360; month++) {
    if (currentBal > 0) {
      const interest = currentBal * (currentRate / 12);
      currentInterest += interest;
      currentBal = Math.max(currentBal + interest - currentRepayment, 0);
    }

    if (proposedBal > 0) {
      const interest = proposedBal * (proposedRate / 12);
      proposedInterest += interest;
      proposedBal = Math.max(proposedBal + interest - proposedRepayment, 0);
    }

    if (currentBal <= 0 && proposedBal <= 0) break;
  }

  return currentInterest - proposedInterest;
};

export const calculateLoanTermChange = (cards: InputCardData[]) => {
  if (cards.length < 2) return 0;

  const current = createFieldValueMap(cards[0]);
  const proposed = createFieldValueMap(cards[1]);

  // Get extra repayments
  let currentExtraRepayment = 0;
  let proposedExtraRepayment = 0;
  if (cards.length > 2) {
    const extraFields = createFieldValueMap(cards[2]);
    currentExtraRepayment = extraFields.get('Current Extra Repayments') ?? 0;
    proposedExtraRepayment = extraFields.get('Proposed Extra Repayments') ?? 0;
  }

  const currentBalance = current.get('Loan Amount') ?? 0;
  const proposedBalance = proposed.get('Loan Amount') ?? currentBalance;

  const currentOffsetBalance = current.get('Offset Account Balance') ?? 0;
  const proposedOffsetBalance = proposed.get('Offset Account Balance') ?? 0;

  const currentRate = (current.get('Interest Rate') ?? 0) / 100;
  const proposedRate = (proposed.get('Interest Rate') ?? 0) / 100;

  const currentRepayment =
    (current.get('Monthly Repayment') ?? 0) + currentExtraRepayment;
  const proposedRepayment =
    (proposed.get('Monthly Repayment') ?? 0) + proposedExtraRepayment;

  // Calculate effective loan amounts (after offset account)
  let currentBal = Math.max(currentBalance - currentOffsetBalance, 0);
  let proposedBal = Math.max(proposedBalance - proposedOffsetBalance, 0);

  let currentMonths = 0;
  let proposedMonths = 0;

  while (currentBal > 0 && currentMonths < 600) {
    const interest = currentBal * (currentRate / 12);
    currentBal = Math.max(currentBal + interest - currentRepayment, 0);
    currentMonths++;
  }

  while (proposedBal > 0 && proposedMonths < 600) {
    const interest = proposedBal * (proposedRate / 12);
    proposedBal = Math.max(proposedBal + interest - proposedRepayment, 0);
    proposedMonths++;
  }

  return currentMonths - proposedMonths;
};
