import { type InputCardData } from './InsuranceContext';

// --- Helpers ---

// Preprocess a card into a lookup map: { 'Annual Premium': 2400, 'Coverage Amount': 500000, ... }
export const createFieldValueMap = (
  card: InputCardData,
): Map<string, number> => {
  const map = new Map<string, number>();
  for (const row of card.inputs) {
    for (const input of row) {
      const fieldParts = input.field.split(',');
      const fieldName = fieldParts[fieldParts.length - 1];
      map.set(fieldName, input.value ?? 0);
    }
  }
  return map;
};

// --- Calculations ---

// Calculate premium costs and coverage over time
export const calculateProjectedCosts = (
  cards: InputCardData[],
  coveragePeriod: number,
): {
  current: number;
  proposed: number;
  currentCoverage: number;
  proposedCoverage: number;
} => {
  if (cards.length < 2)
    return { current: 0, proposed: 0, currentCoverage: 0, proposedCoverage: 0 };

  const [currentCard, proposedCard] = cards;
  const currentFields = createFieldValueMap(currentCard);
  const proposedFields = createFieldValueMap(proposedCard);

  // Get current policy values
  const currentPremium = currentFields.get('Annual Premium') ?? 0;
  const currentCoverage = currentFields.get('Coverage Amount') ?? 0;
  const premiumIncreaseRate =
    (currentFields.get('Premium Increase') ?? 0) / 100;

  // Get proposed policy values
  const proposedPremium = proposedFields.get('Annual Premium') ?? 0;
  const proposedCoverage = proposedFields.get('Coverage Amount') ?? 0;
  const proposedDiscount = (proposedFields.get('Premium Discount') ?? 0) / 100;

  // Additional riders
  const currentRiders = currentFields.get('Additional Riders') ?? 0;
  const proposedRiders = proposedFields.get('Additional Riders') ?? 0;

  // Calculate total premiums over coverage period
  let totalCurrentPremium = 0;
  let totalProposedPremium = 0;
  let currentAnnualPremium = currentPremium + currentRiders;
  let proposedAnnualPremium =
    (proposedPremium + proposedRiders) * (1 - proposedDiscount);

  for (let year = 1; year <= coveragePeriod; year++) {
    totalCurrentPremium += currentAnnualPremium;
    totalProposedPremium += proposedAnnualPremium;

    // Apply premium increases for next year
    currentAnnualPremium *= 1 + premiumIncreaseRate;
    proposedAnnualPremium *= 1 + premiumIncreaseRate;
  }

  return {
    current: Math.round(totalCurrentPremium),
    proposed: Math.round(totalProposedPremium),
    currentCoverage: currentCoverage,
    proposedCoverage: proposedCoverage,
  };
};

// Calculate the coverage-to-cost ratio (higher is better)
export const calculateCoverageToCostRatio = (
  coverage: number,
  totalCost: number,
): number => {
  if (totalCost === 0) return 0;
  return Math.round((coverage / totalCost) * 100) / 100;
};

// Monthly cost difference between current and proposed plans
export const calculateMonthlyCostDifference = (
  cards: InputCardData[],
): number => {
  if (cards.length < 2) return 0;

  const [currentCard, proposedCard] = cards;
  const currentFields = createFieldValueMap(currentCard);
  const proposedFields = createFieldValueMap(proposedCard);

  const currentPremium = currentFields.get('Annual Premium') ?? 0;
  const currentRiders = currentFields.get('Additional Riders') ?? 0;

  const proposedPremium = proposedFields.get('Annual Premium') ?? 0;
  const proposedRiders = proposedFields.get('Additional Riders') ?? 0;
  const proposedDiscount = (proposedFields.get('Premium Discount') ?? 0) / 100;

  const currentMonthly = (currentPremium + currentRiders) / 12;
  const proposedMonthly =
    ((proposedPremium + proposedRiders) * (1 - proposedDiscount)) / 12;

  return Math.round(proposedMonthly - currentMonthly);
};

// Calculate out-of-pocket difference
export const calculateOutOfPocketDifference = (
  cards: InputCardData[],
): number => {
  if (cards.length < 3) return 0;

  const analysisCard = cards[2];
  const analysisFields = createFieldValueMap(analysisCard);

  const currentOutOfPocket =
    analysisFields.get('Current Out-of-Pocket Max') ?? 0;
  const proposedOutOfPocket =
    analysisFields.get('Proposed Out-of-Pocket Max') ?? 0;

  return currentOutOfPocket - proposedOutOfPocket;
};

// Create dataset for bar graph
export const generateInsuranceDataset = (
  cards: InputCardData[],
  coveragePeriod: number,
) => {
  if (cards.length < 2) return [];

  const [currentCard, proposedCard] = cards;
  const currentFields = createFieldValueMap(currentCard);
  const proposedFields = createFieldValueMap(proposedCard);

  // Get current policy values
  const currentPremium = currentFields.get('Annual Premium') ?? 0;
  const currentCoverage = currentFields.get('Coverage Amount') ?? 0;
  const currentClaimProbability =
    (currentFields.get('Claim Probability') ?? 0) / 100;
  const currentDeductible = currentFields.get('Deductible') ?? 0;
  const currentRiders = currentFields.get('Additional Riders') ?? 0;
  const premiumIncreaseRate =
    (currentFields.get('Premium Increase') ?? 0) / 100;

  // Get proposed policy values
  const proposedPremium = proposedFields.get('Annual Premium') ?? 0;
  const proposedCoverage = proposedFields.get('Coverage Amount') ?? 0;
  const proposedDeductible = proposedFields.get('Deductible') ?? 0;
  const proposedRiders = proposedFields.get('Additional Riders') ?? 0;
  const proposedDiscount = (proposedFields.get('Premium Discount') ?? 0) / 100;

  const dataset = [];

  // Track if proposed changes exist
  const hasProposedChanges =
    proposedPremium > 0 ||
    proposedCoverage !== currentCoverage ||
    proposedDeductible !== currentDeductible;

  let cumulativeCurrentPremium = 0;
  let cumulativeProposedPremium = 0;
  let cumulativeCurrentClaims = 0;
  let cumulativeProposedClaims = 0;
  let currentAnnualPremium = currentPremium + currentRiders;
  let proposedAnnualPremium =
    (proposedPremium + proposedRiders) * (1 - proposedDiscount);

  // Step through the years for the coverage period
  for (let year = 0; year <= coveragePeriod; year++) {
    if (year > 0) {
      // Add premiums for this year
      cumulativeCurrentPremium += currentAnnualPremium;
      cumulativeProposedPremium += proposedAnnualPremium;

      // Calculate estimated claims benefit (simplified)
      // This assumes a fixed probability of claim each year
      const currentYearClaim =
        currentClaimProbability * (currentCoverage - currentDeductible);
      const proposedYearClaim =
        currentClaimProbability * (proposedCoverage - proposedDeductible);

      cumulativeCurrentClaims += currentYearClaim;
      cumulativeProposedClaims += proposedYearClaim;

      // Apply premium increases for next year
      currentAnnualPremium *= 1 + premiumIncreaseRate;
      proposedAnnualPremium *= 1 + premiumIncreaseRate;
    }

    dataset.push({
      year,
      currentPremiums: Math.round(cumulativeCurrentPremium),
      currentClaims: Math.round(cumulativeCurrentClaims),
      proposedPremiums: hasProposedChanges
        ? Math.round(cumulativeProposedPremium)
        : 0,
      proposedClaims: hasProposedChanges
        ? Math.round(cumulativeProposedClaims)
        : 0,
    });
  }

  return dataset;
};
