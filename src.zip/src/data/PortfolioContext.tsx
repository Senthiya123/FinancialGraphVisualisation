import React, {
  type ReactNode,
  createContext,
  useContext,
  useState,
} from 'react';

import { useTimeframe } from './TimeframeContext.tsx';

// Define input structure that matches your application's needs
export interface InputCardData {
  name: string;
  variant?: string;
  bg: string;
  inputs: Array<
    Array<{
      field: string;
      value: number;
      defaultValue: number;
    }>
  >;
  showCheckbox?: boolean;
}

// Define the structure of the context
export interface PortfolioContextType {
  inputCards: InputCardData[];
  updateInputValue: (
    cardIndex: number,
    rowIndex: number,
    fieldIndex: number,
    newValue: number,
  ) => void;
  resetToDefaults: () => void;
  saveInputs: () => void;
  timeframe: number;
  setTimeframe: (value: number) => void;
}

// Initial data structure based on your application
const initialInputCards: InputCardData[] = [
  {
    name: 'Charles Davies',
    variant: 'OWN FUNDS',
    bg: '#b1d45a',
    inputs: [
      [
        { field: '$,Lump Sum', value: 5000, defaultValue: 5000 },
        { field: '$,DCA Monthly', value: 200, defaultValue: 200 },
      ],
    ],
  },
  {
    name: 'Charles Davies',
    variant: 'BORROWED FUNDS',
    bg: '#eafcb7',
    inputs: [
      [
        { field: '$,Lump Sum', value: 5000, defaultValue: 5000 },
        { field: '$,DCA Monthly', value: 300, defaultValue: 300 },
      ],
      [{ field: '%,Current Loan to Value Ratio', value: 60, defaultValue: 60 }],
    ],
  },
  {
    name: 'Superannuation Recycling',
    bg: '#edf2f7',
    inputs: [
      [
        {
          field: '$,Annual Concessional Contribution',
          value: 27500,
          defaultValue: 27500,
        },
        {
          field: '%,Recycling Allocation from Super',
          value: 15,
          defaultValue: 15,
        },
      ],
    ],
  },
];

// Create the context with a default value (with initial empty implementation)
export const PortfolioContext = createContext<PortfolioContextType>({
  inputCards: [],
  updateInputValue: () => {},
  resetToDefaults: () => {},
  saveInputs: () => {},
  timeframe: 30,
  setTimeframe: () => {},
});

// Provider component
export const PortfolioProvider: React.FC<{ children: ReactNode }> = ({
  children,
}) => {
  const [inputCards, setInputCards] =
    useState<InputCardData[]>(initialInputCards);
  const { timeframe, setTimeframe } = useTimeframe();

  // Update a specific input value
  const updateInputValue = (
    cardIndex: number,
    rowIndex: number,
    fieldIndex: number,
    newValue: number,
  ) => {
    setInputCards((prevCards) => {
      const newCards = [...prevCards];
      if (
        newCards[cardIndex] &&
        newCards[cardIndex].inputs[rowIndex] &&
        newCards[cardIndex].inputs[rowIndex][fieldIndex]
      ) {
        newCards[cardIndex].inputs[rowIndex][fieldIndex].value = newValue;
      }
      return newCards;
    });
  };

  // Reset all inputs to their default values
  const resetToDefaults = () => {
    setInputCards((prevCards) => {
      return prevCards.map((card) => ({
        ...card,
        checked: false,
        inputs: card.inputs.map((row) =>
          row.map((input) => ({
            ...input,
            value: input.defaultValue,
          })),
        ),
      }));
    });
  };

  // Save current inputs (in a real app, this might save to local storage or backend)
  const saveInputs = () => {
    // In a real implementation, you might save to localStorage or a backend here
    console.log('Saving inputs:', inputCards);
    // For now, this is just a placeholder - the state is already saved in React state
  };

  const contextValue: PortfolioContextType = {
    inputCards,
    updateInputValue,
    resetToDefaults,
    saveInputs,
    timeframe,
    setTimeframe,
  };

  return (
    <PortfolioContext.Provider value={contextValue}>
      {children}
    </PortfolioContext.Provider>
  );
};

// Custom hook to use the context
export const usePortfolio = (): PortfolioContextType => {
  return useContext(PortfolioContext);
};
