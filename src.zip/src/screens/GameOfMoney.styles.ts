import { type SystemStyleObject } from '@chakra-ui/react';

export const GameLayoutSx: SystemStyleObject = {
  w: '100%',
  h: '100%',
  justifyContent: 'space-between',
  gap: 0,
};

export const LeftColumnSx: SystemStyleObject = {
  w: '250px',
  h: '100%',
  alignItems: 'flex-start',
  justifyContent: 'center',
};

export const LeftColumnInnerSx: SystemStyleObject = {
  w: '150px',
  gap: 7,
  justifyContent: 'center',
};

export const CenterColumnSx: SystemStyleObject = {
  h: '100%',
  gap: '10',
};

export const TextHeadingSx: SystemStyleObject = {
  fontSize: '2xl',
  textAlign: 'center',
  color: '#58585a',
};

export const TextSubheadingSx: SystemStyleObject = {
  color: '#718096',
};

export const RightColumnSx: SystemStyleObject = {
  w: '250px',
  h: '100%',
  alignItems: 'flex-end',
  gap: '5',
};
