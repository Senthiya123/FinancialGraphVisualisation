import { Box, HStack, Text, VStack } from '@chakra-ui/react';
import { useState } from 'react';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';

import {
  CenterColumnSx,
  GameLayoutSx,
  LeftColumnInnerSx,
  LeftColumnSx,
  RightColumnSx,
  TextHeadingSx,
  TextSubheadingSx,
} from './GameOfMoney.styles.ts';
import { EstimatedBudgetCard } from '../components/atoms/EstimatedBudgetCard.tsx';
import { ProposedBudgetCard } from '../components/atoms/ProposedBudgetCard.tsx';
import { TimeframeSlider } from '../components/atoms/TimeframeSlider.tsx';
import { AllProviders } from '../data/AllProviders.tsx';
import { TimeframeProvider } from '../data/TimeframeContext.tsx';
import { InsuranceProjections } from './modals/projections/InsuranceProjections.tsx';
import { LoanProjections } from './modals/projections/LoanProjections.tsx';
import { SavingsProjections } from './modals/projections/SavingsProjections.tsx';
import { type TokenType } from '../components/atoms/tokens/Token.tsx';
import Dropzone from '../components/Dropzone.tsx';
import { TokenColumn } from '../components/TokenColumn.tsx';
import { PortfolioProjections } from './modals/projections/PortfolioProjections.tsx';
import { SuperannuationProjections } from './modals/projections/SuperannuationProjections.tsx';

export const GameOfMoney = () => {
  // Keep track of which tokens are in the dropzone
  const [droppedTokenTypes, setDroppedTokenTypes] = useState<Set<TokenType>>(
    new Set(),
  );

  // State to control whether to show modal content
  // TODO - change back to false
  const [showModalContent, setShowModalContent] = useState(false);

  // State to track active token being edited
  const [activeToken, setActiveToken] = useState<TokenType | null>(null);

  // Handler for when tokens are dropped
  const handleTokenDrop = (tokenType: TokenType) => {
    setDroppedTokenTypes((prev) => {
      const newSet = new Set(prev);
      newSet.add(tokenType);
      return newSet;
    });

    // Show modal content and set active token
    setActiveToken(tokenType);
    setShowModalContent(true);
  };

  // Handler for when tokens are removed from dropzone
  const handleTokenRemove = (tokenType: TokenType) => {
    setDroppedTokenTypes((prev) => {
      const newSet = new Set(prev);
      newSet.delete(tokenType);
      return newSet;
    });

    // If we're removing the active token, close the modal content
    if (activeToken === tokenType) {
      setShowModalContent(false);
      setActiveToken(null);
    }
  };

  // Handler for when a token in the dropzone is clicked
  const handleTokenClick = (tokenType: TokenType) => {
    setActiveToken(tokenType);
    setShowModalContent(true);
  };

  // Handler for closing the modal content
  const handleCloseModalContent = () => {
    setShowModalContent(false);
    setActiveToken(null);
  };

  // Convert Set to Array for passing to Dropzone
  const droppedTokensArray = Array.from(droppedTokenTypes);

  return (
    <DndProvider backend={HTML5Backend}>
      <TimeframeProvider>
        <Box position="relative">
          <HStack sx={GameLayoutSx}>
            <VStack sx={LeftColumnSx}>
              <VStack sx={LeftColumnInnerSx}>
                <TimeframeSlider />
                <TokenColumn droppedTokenTypes={droppedTokenTypes} />
              </VStack>
            </VStack>

            <VStack sx={CenterColumnSx}>
              <VStack gap={0}>
                <Text sx={TextHeadingSx}>
                  Hello <b>Charles</b>, how can we help you reach your goals?
                </Text>
                <Text sx={TextSubheadingSx}>
                  Click on a token on the left and drop it in the centre...
                </Text>
              </VStack>
              <AllProviders>
                <Dropzone
                  onTokenDrop={handleTokenDrop}
                  droppedTokens={droppedTokensArray}
                  onTokenRemove={handleTokenRemove}
                  onTokenClick={handleTokenClick}
                />
              </AllProviders>
            </VStack>
            <VStack sx={RightColumnSx}>
              <AllProviders>
                <EstimatedBudgetCard />
                <ProposedBudgetCard droppedTokensArray={droppedTokensArray} />
              </AllProviders>
            </VStack>
          </HStack>
          {showModalContent && (
            <Box
              position="absolute"
              top="0"
              left="0"
              width="100%"
              height="100%"
              zIndex={10}
              bg="white"
            >
              {activeToken === 'insurance' && (
                <InsuranceProjections
                  onClose={handleCloseModalContent}
                  tokenType={activeToken}
                />
              )}
              {activeToken === 'super' && (
                <SuperannuationProjections
                  onClose={handleCloseModalContent}
                  tokenType={activeToken}
                />
              )}
              {activeToken === 'savings' && (
                <SavingsProjections
                  onClose={handleCloseModalContent}
                  tokenType={activeToken}
                />
              )}
              {activeToken === 'loans' && (
                <LoanProjections
                  onClose={handleCloseModalContent}
                  tokenType={activeToken}
                />
              )}
              {activeToken === 'portfolio' && (
                <PortfolioProjections
                  onClose={handleCloseModalContent}
                  tokenType={activeToken}
                />
              )}
            </Box>
          )}
        </Box>
      </TimeframeProvider>
    </DndProvider>
  );
};
