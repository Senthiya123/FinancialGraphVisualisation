import type { TokenType } from '../../../components/atoms/tokens/Token.tsx';
import {
  SuperannuationProvider,
  useSuperannuation,
} from '../../../data/SuperannuationContext.tsx';
import { SuperBarGraph } from '../graphs/SuperBarGraph.tsx';
import { ModalLayout } from '../ModalLayout.tsx';
import { SuperSummary } from '../summarybars/SuperSummary.tsx';

interface ModalLayoutProps {
  onClose: () => void;
  tokenType: TokenType | null;
}

export const SuperannuationProjections = ({
  onClose,
  tokenType,
}: ModalLayoutProps) => {
  return (
    <SuperannuationProvider>
      <ModalLayoutWithContext onClose={onClose} tokenType={tokenType} />
    </SuperannuationProvider>
  );
};

// Memoized component to avoid unnecessary re-renders
const ModalLayoutWithContext = ({ onClose, tokenType }: ModalLayoutProps) => {
  const { inputCards, updateInputValue, updateCheckboxValue } =
    useSuperannuation();

  return (
    <ModalLayout
      onClose={onClose}
      tokenType={tokenType}
      GraphComponent={SuperBarGraph}
      SummaryComponent={SuperSummary}
      inputCards={inputCards}
      updateInputValue={updateInputValue}
      updateCheckboxValue={updateCheckboxValue}
    />
  );
};
