import type { TokenType } from '../../../components/atoms/tokens/Token';
import {
  InsuranceProvider,
  useInsurance,
} from '../../../data/InsuranceContext';
import { InsuranceBarGraph } from '../graphs/InsuranceBarGraph';
import { ModalLayout } from '../ModalLayout';
import { InsuranceSummary } from '../summarybars/InsuranceSummary.tsx';

interface InsuranceProjectionsProps {
  onClose: () => void;
  tokenType: TokenType | null;
}

export const InsuranceProjections = ({
  onClose,
  tokenType,
}: InsuranceProjectionsProps) => {
  return (
    <InsuranceProvider>
      <ModalLayoutWithContext onClose={onClose} tokenType={tokenType} />
    </InsuranceProvider>
  );
};

// Memoized child
const ModalLayoutWithContext = ({
  onClose,
  tokenType,
}: InsuranceProjectionsProps) => {
  const { inputCards, updateInputValue, updateCheckboxValue } = useInsurance();

  return (
    <ModalLayout
      onClose={onClose}
      tokenType={tokenType}
      GraphComponent={InsuranceBarGraph}
      SummaryComponent={InsuranceSummary}
      inputCards={inputCards}
      updateInputValue={updateInputValue}
      updateCheckboxValue={updateCheckboxValue}
    />
  );
};
