import type { TokenType } from '../../../components/atoms/tokens/Token.tsx';
import { SavingsProvider, useSavings } from '../../../data/SavingsContext.tsx';
import { SavingsBarGraph } from '../graphs/SavingsBarGraph.tsx';
import { ModalLayout } from '../ModalLayout.tsx';
import { SavingsSummary } from '../summarybars/SavingsSummary.tsx';

interface ModalLayoutProps {
  onClose: () => void;
  tokenType: TokenType | null;
}

export const SavingsProjections = ({
  onClose,
  tokenType,
}: ModalLayoutProps) => {
  return (
    <SavingsProvider>
      <ModalLayoutWithContext onClose={onClose} tokenType={tokenType} />
    </SavingsProvider>
  );
};

// Memoized child
const ModalLayoutWithContext = ({ onClose, tokenType }: ModalLayoutProps) => {
  const { inputCards, updateInputValue } = useSavings();

  return (
    <ModalLayout
      onClose={onClose}
      tokenType={tokenType}
      GraphComponent={SavingsBarGraph}
      SummaryComponent={SavingsSummary}
      inputCards={inputCards}
      updateInputValue={updateInputValue}
    />
  );
};
