import type { TokenType } from '../../../components/atoms/tokens/Token';
import {
  PortfolioProvider,
  usePortfolio,
} from '../../../data/PortfolioContext';
import { PortfolioBarGraph } from '../graphs/PortfolioBarGraph';
import { ModalLayout } from '../ModalLayout';
import { PortfolioSummary } from '../summarybars/PortfolioSummary.tsx';

interface PortfolioProjectionsProps {
  onClose: () => void;
  tokenType: TokenType | null;
}

export const PortfolioProjections = ({
  onClose,
  tokenType,
}: PortfolioProjectionsProps) => {
  return (
    <PortfolioProvider>
      <ModalLayoutWithContext onClose={onClose} tokenType={tokenType} />
    </PortfolioProvider>
  );
};

// Memoized child
const ModalLayoutWithContext = ({
  onClose,
  tokenType,
}: PortfolioProjectionsProps) => {
  const { inputCards, updateInputValue } = usePortfolio();

  return (
    <ModalLayout
      onClose={onClose}
      tokenType={tokenType}
      GraphComponent={PortfolioBarGraph}
      SummaryComponent={PortfolioSummary}
      inputCards={inputCards}
      updateInputValue={updateInputValue}
    />
  );
};
