import type { TokenType } from '../../../components/atoms/tokens/Token';
import { LoansProvider, useLoans } from '../../../data/LoansContext.tsx';
import { LoanBarGraph } from '../graphs/LoansBarGraph.tsx';
import { ModalLayout } from '../ModalLayout';
import { LoanSummary } from '../summarybars/LoansSummary.tsx';

interface LoanProjectionsProps {
  onClose: () => void;
  tokenType: TokenType | null;
}

export const LoanProjections = ({
  onClose,
  tokenType,
}: LoanProjectionsProps) => {
  return (
    <LoansProvider>
      <ModalLayoutWithContext onClose={onClose} tokenType={tokenType} />
    </LoansProvider>
  );
};

// Memoized child
const ModalLayoutWithContext = ({
  onClose,
  tokenType,
}: LoanProjectionsProps) => {
  const { inputCards, updateInputValue } = useLoans();

  return (
    <ModalLayout
      onClose={onClose}
      tokenType={tokenType}
      GraphComponent={LoanBarGraph}
      SummaryComponent={LoanSummary}
      inputCards={inputCards}
      updateInputValue={updateInputValue}
    />
  );
};
