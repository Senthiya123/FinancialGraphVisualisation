import { Box, Button, Flex, Text, VStack } from '@chakra-ui/react';
import { useMemo } from 'react';

import {
  calculateInterestSaved,
  calculateLoanTermChange,
  calculateMonthlyRepaymentChange,
  calculateTotalLoanAmount,
} from '../../../data/LoansCalculations';
import { useLoans } from '../../../data/LoansContext';

interface LoanSummaryProps {
  onClose: () => void;
  timeframe?: number;
}

export const LoanSummary = ({ onClose, timeframe }: LoanSummaryProps) => {
  const {
    inputCards,
    saveInputs,
    resetToDefaults,
    timeframe: contextTimeframe,
  } = useLoans();

  // Use the timeframe from context if provided, otherwise use the prop value
  const effectiveTimeframe = contextTimeframe || timeframe || 30;

  const calculatedLoanStats = useMemo(() => {
    const totalLoanAmount = calculateTotalLoanAmount(inputCards);
    const monthlyRepaymentChange = calculateMonthlyRepaymentChange(inputCards);
    const interestSaved = calculateInterestSaved(inputCards);
    const termChange = calculateLoanTermChange(inputCards);

    return {
      totalLoanAmount,
      monthlyRepaymentChange,
      interestSaved,
      termChange,
    };
  }, [inputCards, effectiveTimeframe]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-AU', {
      style: 'currency',
      currency: 'AUD',
      maximumFractionDigits: 0,
    }).format(value);
  };

  return (
    <Box bg="#4299e1" borderRadius="4px" w="100%" p={4}>
      <Flex direction="row" justifyContent="space-between">
        {/* Left Block */}
        <VStack align="flex-start" spacing={0} color="white">
          <Text fontSize="md" fontWeight="bold">
            Current loan amount
          </Text>
          <Text fontSize="4xl">
            {formatCurrency(calculatedLoanStats.totalLoanAmount)}
          </Text>
          <Text fontSize="xs" fontWeight="bold">
            Monthly repayments would{' '}
            {calculatedLoanStats.monthlyRepaymentChange >= 0
              ? 'increase'
              : 'decrease'}{' '}
            by{' '}
            {formatCurrency(
              Math.abs(calculatedLoanStats.monthlyRepaymentChange),
            )}
          </Text>
        </VStack>

        {/* Center Block */}
        <VStack align="flex-start" color="white">
          <VStack spacing={0} align="center" w="100%">
            <Text fontSize="md" fontWeight="medium">
              Total interest saved
            </Text>
            <Text fontSize="4xl" fontWeight="bold">
              {formatCurrency(calculatedLoanStats.interestSaved)}
            </Text>
            <Text fontSize="xs">
              {calculatedLoanStats.termChange !== 0
                ? `Loan term ${calculatedLoanStats.termChange > 0 ? 'increased' : 'reduced'} by ${Math.abs(calculatedLoanStats.termChange)} months`
                : 'Loan term unchanged'}
            </Text>
          </VStack>
        </VStack>

        {/* Buttons */}
        <VStack spacing={2} w="124px">
          <Button
            w="100%"
            variant="outline"
            color="white"
            borderColor="white"
            _hover={{ bg: 'whiteAlpha.300' }}
            onClick={function () {
              resetToDefaults();
              onClose();
            }}
          >
            CANCEL
          </Button>
          <Button
            w="100%"
            bg="white"
            color="#4299e1"
            _hover={{ bg: 'whiteAlpha.900' }}
            onClick={() => {
              saveInputs();
              onClose();
            }}
          >
            SAVE
          </Button>
        </VStack>
      </Flex>
    </Box>
  );
};
