import { Box, Button, Flex, Text, VStack } from '@chakra-ui/react';
import { useMemo } from 'react';

import {
  calculateAnnualIncome,
  calculateProjectedBalance,
  calculateWeeklyCost,
} from '../../../data/SuperannuationCalculations.ts';
import { useSuperannuation } from '../../../data/SuperannuationContext.tsx';
import { useTimeframe } from '../../../data/TimeframeContext.tsx';

interface ModalProposedSummaryProps {
  onClose: () => void;
}

export const SuperSummary = ({ onClose }: ModalProposedSummaryProps) => {
  const { timeframe } = useTimeframe();
  const { inputCards, saveInputs, resetToDefaults } = useSuperannuation();

  // Calculate estimated benefits based on input values
  const calculatedBenefits = useMemo(() => {
    const projectedBalances = calculateProjectedBalance(inputCards, timeframe);
    const weeklyContribution = calculateWeeklyCost(inputCards);
    const yearlyIncome = calculateAnnualIncome(projectedBalances.proposed);

    return {
      totalBenefit: projectedBalances.proposed,
      weeklyContribution: weeklyContribution,
      yearlyIncome: yearlyIncome,
    };
  }, [inputCards, timeframe]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-AU', {
      style: 'currency',
      currency: 'AUD',
      maximumFractionDigits: 0,
    }).format(value);
  };

  return (
    <Box bg="#4299e1" borderRadius="4px" w="100%" p={4}>
      <Flex direction="row" justifyContent="space-between">
        {/* Left Block */}
        <VStack align="flex-start" spacing={0} color="white">
          <Text fontSize="md" fontWeight="bold">
            Proposed strategy benefits generates
          </Text>
          <Text fontSize="4xl">
            {calculatedBenefits.totalBenefit
              ? formatCurrency(calculatedBenefits.totalBenefit)
              : formatCurrency(0)}
          </Text>
          <Text fontSize="xs" fontWeight="bold">
            This strategy would cost you{' '}
            {calculatedBenefits.weeklyContribution
              ? formatCurrency(calculatedBenefits.weeklyContribution)
              : formatCurrency(0)}{' '}
            a week
          </Text>
        </VStack>

        {/* Center Block */}
        <VStack align="flex-start" color="white">
          <VStack spacing={0} align="center" w="100%">
            <Text fontSize="md" fontWeight="medium">
              INCOME ESTIMATE PER YEAR
            </Text>
            <Text fontSize="4xl" fontWeight="bold">
              {calculatedBenefits.yearlyIncome
                ? formatCurrency(calculatedBenefits.yearlyIncome)
                : formatCurrency(0)}
            </Text>
          </VStack>
        </VStack>

        {/* Buttons */}
        <VStack spacing={2} w={'124px'}>
          <Button
            w="100%"
            variant="outline"
            color="white"
            borderColor="white"
            _hover={{ bg: 'whiteAlpha.300' }}
            onClick={function () {
              resetToDefaults();
              onClose();
            }}
          >
            CANCEL
          </Button>
          <Button
            w="100%"
            bg="white"
            color="#4299e1"
            _hover={{ bg: 'whiteAlpha.900' }}
            onClick={function () {
              saveInputs();
              onClose();
            }}
          >
            SAVE
          </Button>
        </VStack>
      </Flex>
    </Box>
  );
};
