import { Box, Button, Flex, Text, VStack } from '@chakra-ui/react';
import { useMemo } from 'react';

import {
  calculateCoverageToCostRatio,
  calculateMonthlyCostDifference,
  calculateOutOfPocketDifference,
  calculateProjectedCosts,
} from '../../../data/InsuranceCalculations.ts';
import { useInsurance } from '../../../data/InsuranceContext.tsx';

interface ModalProposedSummaryProps {
  onClose: () => void;
  timeframe: number;
}

export const InsuranceSummary = ({
  onClose,
  timeframe,
}: ModalProposedSummaryProps) => {
  const { inputCards, saveInputs, resetToDefaults } = useInsurance();

  // Calculate estimated benefits based on input values
  const calculatedBenefits = useMemo(() => {
    const projectedCosts = calculateProjectedCosts(inputCards, timeframe);
    const coverageToCostRatio = calculateCoverageToCostRatio(
      projectedCosts.proposedCoverage,
      projectedCosts.proposed,
    );
    const monthlyCostDifference = calculateMonthlyCostDifference(inputCards);
    const outOfPocketSavings = calculateOutOfPocketDifference(inputCards);

    return {
      totalCoverage: projectedCosts.proposedCoverage,
      monthlyCostDifference: monthlyCostDifference,
      coverageToCostRatio: coverageToCostRatio,
      outOfPocketSavings: outOfPocketSavings,
    };
  }, [inputCards, timeframe]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-AU', {
      style: 'currency',
      currency: 'AUD',
      maximumFractionDigits: 0,
    }).format(value);
  };

  return (
    <Box bg="#4299e1" borderRadius="4px" w="100%" p={4}>
      <Flex direction="row" justifyContent="space-between">
        {/* Left Block */}
        <VStack align="flex-start" spacing={0} color="white">
          <Text fontSize="md" fontWeight="bold">
            Proposed plan provides coverage of
          </Text>
          <Text fontSize="4xl">
            {calculatedBenefits.totalCoverage
              ? formatCurrency(calculatedBenefits.totalCoverage)
              : formatCurrency(0)}
          </Text>
          <Text fontSize="xs" fontWeight="bold">
            This plan would{' '}
            {calculatedBenefits.monthlyCostDifference >= 0 ? 'cost' : 'save'}{' '}
            you{' '}
            {calculatedBenefits.monthlyCostDifference
              ? formatCurrency(
                  Math.abs(calculatedBenefits.monthlyCostDifference),
                )
              : formatCurrency(0)}{' '}
            per month
          </Text>
        </VStack>

        {/* Center Block */}
        <VStack align="flex-start" color="white">
          <VStack spacing={0} align="center" w="100%">
            <Text fontSize="md" fontWeight="medium">
              COVERAGE-TO-COST RATIO
            </Text>
            <Flex align="baseline">
              <Text fontSize="4xl" fontWeight="bold">
                {calculatedBenefits.coverageToCostRatio.toFixed(1)}
              </Text>
              <Text fontSize="lg" ml={1}>
                :1
              </Text>
            </Flex>
            <Text fontSize="xs">
              {calculatedBenefits.outOfPocketSavings > 0
                ? `Reduces out-of-pocket max by ${formatCurrency(calculatedBenefits.outOfPocketSavings)}`
                : ''}
            </Text>
          </VStack>
        </VStack>

        {/* Buttons */}
        <VStack spacing={2} w={'124px'}>
          <Button
            w="100%"
            variant="outline"
            color="white"
            borderColor="white"
            _hover={{ bg: 'whiteAlpha.300' }}
            onClick={function () {
              resetToDefaults();
              onClose();
            }}
          >
            CANCEL
          </Button>
          <Button
            w="100%"
            bg="white"
            color="#4299e1"
            _hover={{ bg: 'whiteAlpha.900' }}
            onClick={function () {
              saveInputs();
              onClose();
            }}
          >
            SAVE
          </Button>
        </VStack>
      </Flex>
    </Box>
  );
};
