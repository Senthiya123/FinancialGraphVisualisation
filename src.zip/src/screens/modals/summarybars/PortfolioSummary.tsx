// PortfolioSummary.tsx
import { Box, Button, Flex, Text, VStack } from '@chakra-ui/react';
import { useMemo } from 'react';

import {
  calculateAnnualPortfolioContributions,
  calculateMonthlyInvestmentDifference,
  calculatePortfolioProgress,
  calculateProjectedPortfolioValue,
} from '../../../data/PortfolioCalculations.ts';
import { usePortfolio } from '../../../data/PortfolioContext.tsx';

interface ModalProposedSummaryProps {
  onClose: () => void;
}

export const PortfolioSummary = ({ onClose }: ModalProposedSummaryProps) => {
  const { inputCards, saveInputs, resetToDefaults, timeframe } = usePortfolio();

  const summary = useMemo(() => {
    const projected = calculateProjectedPortfolioValue(inputCards, timeframe);
    const monthlyDiff = calculateMonthlyInvestmentDifference(inputCards);
    const annualContributions =
      calculateAnnualPortfolioContributions(inputCards);
    const progress = calculatePortfolioProgress(inputCards);

    return {
      totalValue: projected.proposed,
      monthlyCost: monthlyDiff,
      annualContribution: annualContributions.proposed,
      proposedProgress: progress.proposedProgress,
    };
  }, [inputCards, timeframe]);

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('en-AU', {
      style: 'currency',
      currency: 'AUD',
      maximumFractionDigits: 0,
    }).format(value);

  return (
    <Box bg="#4299e1" borderRadius="4px" w="100%" p={4}>
      <Flex direction="row" justifyContent="space-between" color="white">
        {/* Left Block */}
        <VStack align="flex-start" spacing={0}>
          <Text fontSize="md" fontWeight="bold">
            Portfolio value in {timeframe} years
          </Text>
          <Text fontSize="4xl">{formatCurrency(summary.totalValue)}</Text>
          <Text fontSize="xs" fontWeight="bold">
            Strategy costs you {formatCurrency(summary.monthlyCost)} per month
          </Text>
        </VStack>

        {/* Center Block */}
        <VStack align="flex-start">
          <VStack spacing={0} align="center" w="100%">
            <Text fontSize="md" fontWeight="medium">
              ANNUAL CONTRIBUTION
            </Text>
            <Text fontSize="4xl" fontWeight="bold">
              {formatCurrency(summary.annualContribution)}
            </Text>
            <Text fontSize="xs" fontWeight="medium">
              Portfolio is {summary.proposedProgress}% of your goal
            </Text>
          </VStack>
        </VStack>

        {/* Buttons */}
        <VStack spacing={2} w="124px">
          <Button
            w="100%"
            variant="outline"
            color="white"
            borderColor="white"
            _hover={{ bg: 'whiteAlpha.300' }}
            onClick={function () {
              resetToDefaults();
              onClose();
            }}
          >
            CANCEL
          </Button>
          <Button
            w="100%"
            bg="white"
            color="#4299e1"
            _hover={{ bg: 'whiteAlpha.900' }}
            onClick={() => {
              saveInputs();
              onClose();
            }}
          >
            SAVE
          </Button>
        </VStack>
      </Flex>
    </Box>
  );
};
