import { Box, Button, Flex, Text, VStack } from '@chakra-ui/react';
import { useMemo } from 'react';

import {
  calculateGoalProgress,
  calculateMonthlySavingsDifference,
  calculateProjectedSavings,
  calculateTimeToGoal,
} from '../../../data/SavingsCalculations.ts';
import { useSavings } from '../../../data/SavingsContext.tsx';

interface ModalProposedSummaryProps {
  onClose: () => void;
}

export const SavingsSummary = ({ onClose }: ModalProposedSummaryProps) => {
  const { inputCards, saveInputs, resetToDefaults, timeframe } = useSavings();

  // Define goal amount for calculations
  const goalAmount = 50000; // Example goal amount, replace with actual goal or make configurable

  // Calculate estimated benefits based on input values
  const calculatedBenefits = useMemo(() => {
    const projectedSavings = calculateProjectedSavings(inputCards, timeframe);
    const monthlyContributionDiff =
      calculateMonthlySavingsDifference(inputCards);
    const timeToGoal = calculateTimeToGoal(inputCards, goalAmount);
    const goalProgress = calculateGoalProgress(inputCards);

    return {
      totalProjected: projectedSavings.proposed,
      currentProjected: projectedSavings.current,
      monthlyDifference: monthlyContributionDiff,
      timeToGoalCurrent: timeToGoal.currentMonths,
      timeToGoalProposed: timeToGoal.proposedMonths,
      goalProgressCurrent: goalProgress.currentProgress,
      goalProgressProposed: goalProgress.proposedProgress,
    };
  }, [inputCards, timeframe, goalAmount]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-AU', {
      style: 'currency',
      currency: 'AUD',
      maximumFractionDigits: 0,
    }).format(value);
  };

  const formatMonths = (months: number) => {
    if (months < 0) return 'Never';
    const years = Math.floor(months / 12);
    const remainingMonths = months % 12;

    if (years === 0)
      return `${remainingMonths} month${remainingMonths !== 1 ? 's' : ''}`;
    if (remainingMonths === 0) return `${years} year${years !== 1 ? 's' : ''}`;
    return `${years} year${years !== 1 ? 's' : ''}, ${remainingMonths} month${remainingMonths !== 1 ? 's' : ''}`;
  };

  return (
    <Box bg="#4299e1" borderRadius="4px" w="100%" p={4}>
      <Flex direction="row" justifyContent="space-between">
        {/* Left Block */}
        <VStack align="flex-start" color="white">
          <VStack spacing={0} align="flex-start" w="100%">
            <Text fontSize="md" fontWeight="bold" mb={2}>
              Proposed savings strategy projects
            </Text>
            <Text fontSize="xl">
              Current: {formatMonths(calculatedBenefits.timeToGoalCurrent)}
            </Text>
            <Text fontSize="xl">
              Proposed: {formatMonths(calculatedBenefits.timeToGoalProposed)}
            </Text>
          </VStack>
        </VStack>

        <VStack align="flex-start" spacing={0} color="white">
          <VStack spacing={0} align="center" color="white">
            <Text fontSize="md" fontWeight="bold">
              Proposed savings strategy projects
            </Text>
            <Text fontSize="4xl">
              {calculatedBenefits.totalProjected
                ? formatCurrency(calculatedBenefits.totalProjected)
                : formatCurrency(0)}
            </Text>
            <Text fontSize="xs" fontWeight="bold">
              This strategy would require{' '}
              {calculatedBenefits.monthlyDifference > 0
                ? formatCurrency(calculatedBenefits.monthlyDifference)
                : formatCurrency(0)}{' '}
              additional monthly contributions
            </Text>
          </VStack>
        </VStack>

        {/* Buttons */}
        <VStack spacing={2} w={'124px'}>
          <Button
            w="100%"
            variant="outline"
            color="white"
            borderColor="white"
            _hover={{ bg: 'whiteAlpha.300' }}
            onClick={function () {
              resetToDefaults();
              onClose();
            }}
          >
            CANCEL
          </Button>
          <Button
            w="100%"
            bg="white"
            color="#4299e1"
            _hover={{ bg: 'whiteAlpha.900' }}
            onClick={function () {
              saveInputs();
              onClose();
            }}
          >
            SAVE
          </Button>
        </VStack>
      </Flex>
    </Box>
  );
};
