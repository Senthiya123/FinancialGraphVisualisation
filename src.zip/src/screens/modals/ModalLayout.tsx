import { Flex, HStack, VStack } from '@chakra-ui/react';
import { type ElementType } from 'react';

import { BarGraph } from './components/BarGraph.tsx';
import { ModalHeader } from './components/ModalHeader';
import { ModalInputs } from './components/ModalInputs';
import { type TokenType } from '../../components/atoms/tokens/Token.tsx';
import { useTimeframe } from '../../data/TimeframeContext.tsx';

interface ModalLayoutProps {
  onClose: () => void;
  tokenType: TokenType | null;
  GraphComponent?: ElementType;
  SummaryComponent: ElementType;
  inputCards: Array<{
    name: string;
    variant?: string;
    bg: string;
    showCheckbox?: boolean;
    inputs: Array<
      Array<{ field: string; value: number; defaultValue: number }>
    >;
    applyMaxSCG?: boolean;
  }>;
  updateInputValue: (
    cardIndex: number,
    rowIndex: number,
    fieldIndex: number,
    newValue: number,
  ) => void;
  updateCheckboxValue?: (cardIndex: number, checked: boolean) => void;
}

export const ModalLayout = ({
  onClose,
  tokenType,
  GraphComponent = BarGraph,
  SummaryComponent,
  inputCards,
  updateInputValue,
  updateCheckboxValue,
}: ModalLayoutProps) => {
  const { timeframe } = useTimeframe(); // (Shared across all)

  return (
    <VStack gap={0} w="100%" h="100%">
      <ModalHeader onClose={onClose} tokenType={tokenType} />
      <HStack w="100%" h="100%" spacing={4} align="stretch">
        <Flex flex="3" borderLeftRadius="md">
          <ModalInputs
            inputCards={inputCards}
            updateInputValue={updateInputValue}
            updateCheckboxValue={updateCheckboxValue}
          />
        </Flex>
        <Flex flex="7" direction="column">
          <VStack w="100%" h="100%" justify="space-between" flex="1">
            <GraphComponent timeframe={timeframe} />
            <SummaryComponent onClose={onClose} timeframe={timeframe} />
          </VStack>
        </Flex>
      </HStack>
    </VStack>
  );
};
