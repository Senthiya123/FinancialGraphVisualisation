import { Divider, Text, VStack } from '@chakra-ui/react';

interface DropzoneValuesProps {
  currentValue: number;
  proposedValue: number;
  hasDroppedTokens: boolean;
}

export const DropzoneValues = ({
  currentValue,
  proposedValue,
  hasDroppedTokens,
}: DropzoneValuesProps) => {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-AU', {
      style: 'currency',
      currency: 'AUD',
      maximumFractionDigits: 0,
    }).format(value);
  };

  return hasDroppedTokens ? (
    <VStack gap={0}>
      <Text fontSize="sm" color="white" fontWeight="semibold" mb={-2}>
        CURRENT VALUE
      </Text>
      <Text fontSize="2xl" color="white" fontWeight="semibold">
        {formatCurrency(currentValue)}
      </Text>
      <Divider
        borderWidth="1px"
        color="white"
        borderColor="white"
        opacity={1}
        my={3}
      />
      <Text fontSize="sm" color="white" fontWeight="semibold" mb={-2}>
        PROPOSED VALUE
      </Text>
      <Text fontSize="4xl" color="white" fontWeight="semibold">
        {formatCurrency(proposedValue)}
      </Text>
    </VStack>
  ) : (
    <VStack gap={0}>
      <Text fontSize="sm" color="white" fontWeight="semibold">
        CURRENT VALUE
      </Text>
      <Text fontSize="4xl" color="white" fontWeight="semibold">
        {formatCurrency(currentValue)}
      </Text>
      <Text fontSize="sm" color="white" fontWeight="semibold">
        You are now here
      </Text>
    </VStack>
  );
};
