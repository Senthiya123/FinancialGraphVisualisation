import { Box, HStack, Icon, Text, VStack } from '@chakra-ui/react';
import { MdOutlineCancel, MdOutlineSavings } from 'react-icons/md';

import { TimeframeSlider } from '../../../components/atoms/TimeframeSlider';
import {
  type TokenType,
  tokenStyles,
} from '../../../components/atoms/tokens/Token.tsx';
import { useTimeframe } from '../../../data/TimeframeContext.tsx';

interface ModalHeaderProps {
  onClose: () => void;
  tokenType: TokenType | null;
}

export const ModalHeader = ({ onClose, tokenType }: ModalHeaderProps) => {
  const { timeframe, setTimeframe } = useTimeframe();

  // Get the icon and label based on the token type
  const getTokenInfo = () => {
    if (!tokenType)
      return { icon: MdOutlineSavings, label: 'Superannuation Projections' };

    const { icon, label } = tokenStyles[tokenType];
    return { icon, label: `${label} Projections` };
  };

  const { icon: TokenIcon, label } = getTokenInfo();

  return (
    <HStack w="100%" display="flex" pb={'18px'}>
      <Box flex={1}>
        <Box width={'150px'}>
          <TimeframeSlider value={timeframe} onChange={setTimeframe} />
        </Box>
      </Box>
      <VStack flex={5} gap={1}>
        <HStack>
          <Icon as={TokenIcon} boxSize={6} color={'#58585a'} />
          <Text fontSize={'2xl'} textColor={'#58585a'}>
            {label}
          </Text>
        </HStack>
        <Text textColor={'#718096'}>
          Improve your{' '}
          {tokenType ? tokenStyles[tokenType].label : 'Superannuation'} by
          increasing your contributions and/or your return.
        </Text>
      </VStack>
      <HStack flex={1} alignSelf="flex-start" justifyContent="flex-end">
        <Box
          display="flex"
          alignItems="center"
          gap="4px"
          cursor="pointer"
          onClick={onClose}
          _hover={{ color: '#718096' }}
        >
          <Icon as={MdOutlineCancel} color="#a0aec0" />
          <Text textColor="#a0aec0" _hover={{ textDecoration: 'underline' }}>
            Close
          </Text>
        </Box>
      </HStack>
    </HStack>
  );
};
