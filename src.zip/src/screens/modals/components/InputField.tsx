import { Box, Input, InputGroup, InputLeftAddon, Text } from '@chakra-ui/react';
import { type ChangeEvent } from 'react';

interface InputFieldProps {
  symbol: string;
  label: string;
  value: number;
  onChange: (value: number) => void;
}

export const InputField = ({
  symbol,
  label,
  value,
  onChange,
}: InputFieldProps) => {
  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value === '' ? 0 : parseFloat(e.target.value);
    onChange(newValue);
  };

  const handleBlur = () => {
    // @ts-ignore
    if (value === '') {
      onChange(0);
    }
  };

  return (
    <Box>
      <Text fontSize={'xs'}>{label}</Text>
      <InputGroup size="sm">
        <InputLeftAddon bg={'#e2e8f0'}>{symbol}</InputLeftAddon>
        <Input
          type="number"
          value={value === 0 ? '' : value}
          placeholder="0"
          bg={'white'}
          onChange={handleChange}
          onBlur={handleBlur}
        />
      </InputGroup>
    </Box>
  );
};
