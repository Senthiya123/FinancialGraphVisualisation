import { Box, Checkbox, HStack, Text, VStack } from '@chakra-ui/react';

import { InputField } from './InputField.tsx';

interface InputCardProps {
  name: string;
  variant?: string;
  bg: string;
  cardIndex: number;
  showCheckbox?: boolean;
  inputCards: any[]; // You can tighten this later
  updateInputValue: (
    cardIndex: number,
    rowIndex: number,
    fieldIndex: number,
    newValue: number,
  ) => void;
  updateCheckboxValue?: (cardIndex: number, checked: boolean) => void; // <-- OPTIONAL
}

export const InputCard = ({
  name,
  variant,
  bg,
  cardIndex,
  showCheckbox = false,
  inputCards,
  updateInputValue,
  updateCheckboxValue,
}: InputCardProps) => {
  const card = inputCards[cardIndex];
  if (!card) return null;

  return (
    <Box bg={bg} w="100%" borderRadius="4px" p={4}>
      <HStack justify="space-between" pb="2">
        <Text fontSize="sm" fontWeight="bold">
          {name}
        </Text>
        {variant && (
          <Text fontSize="sm" fontWeight="bold">
            {variant}
          </Text>
        )}
      </HStack>
      <VStack spacing={2} align="stretch">
        {card.inputs.map((row: any[], rowIdx: number) => (
          <HStack key={rowIdx} spacing={1} w="100%">
            {row.map((item: any, fieldIdx: number) => {
              const [symbol, label] = item.field.split(',');
              return (
                <Box key={fieldIdx} flex="1" maxW="50%">
                  <InputField
                    symbol={symbol}
                    label={label}
                    value={item.value}
                    onChange={(newValue) =>
                      updateInputValue(cardIndex, rowIdx, fieldIdx, newValue)
                    }
                  />
                </Box>
              );
            })}
          </HStack>
        ))}
        {showCheckbox && updateCheckboxValue && (
          <Box pt={2}>
            <Checkbox
              colorScheme="blue"
              isChecked={card.applyMaxSCG}
              onChange={(e) => updateCheckboxValue(cardIndex, e.target.checked)}
              sx={{
                '.chakra-checkbox__control': {
                  background: 'white !important',
                  borderColor: 'gray.300',
                },
                '.chakra-checkbox__control[data-checked]': {
                  background: 'blue.500 !important',
                  borderColor: 'blue.500',
                },
                '&:hover .chakra-checkbox__control:not([data-checked])': {
                  background: 'gray.50 !important',
                },
              }}
            >
              Apply SCG maximum amount
            </Checkbox>
          </Box>
        )}
      </VStack>
    </Box>
  );
};
