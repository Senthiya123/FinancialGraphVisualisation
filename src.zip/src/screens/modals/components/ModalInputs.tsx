import { VStack } from '@chakra-ui/react';

import { InputCard } from './InputCard.tsx';

interface ModalInputsProps {
  inputCards: Array<{
    name: string;
    variant?: string;
    bg: string;
    showCheckbox?: boolean;
    inputs: Array<
      Array<{ field: string; value: number; defaultValue: number }>
    >;
    applyMaxSCG?: boolean;
  }>;
  updateInputValue: (
    cardIndex: number,
    rowIndex: number,
    fieldIndex: number,
    newValue: number,
  ) => void;
  updateCheckboxValue?: (cardIndex: number, checked: boolean) => void; // <-- OPTIONAL
}

export const ModalInputs = ({
  inputCards,
  updateInputValue,
  updateCheckboxValue,
}: ModalInputsProps) => {
  return (
    <VStack>
      {inputCards.map((card, index) => (
        <InputCard
          key={index}
          name={card.name}
          variant={card.variant}
          bg={card.bg}
          cardIndex={index}
          showCheckbox={card.showCheckbox}
          inputCards={inputCards}
          updateInputValue={updateInputValue}
          updateCheckboxValue={updateCheckboxValue}
        />
      ))}
    </VStack>
  );
};
