import { Box, Text } from '@chakra-ui/react';
import { CssBaseline } from '@mui/material';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { BarChart, barElementClasses, lineElementClasses } from '@mui/x-charts';
import { MdOutlineSavings } from 'react-icons/md';

import {
  type TokenType,
  tokenStyles,
} from '../../../components/atoms/tokens/Token.tsx';
import { portfolioInvestments } from '../../../data/dataset.ts';

const muiTheme = createTheme({
  palette: {
    mode: 'light',
  },
});

interface BarGraphProps {
  timeframe?: number; // default = 30
  tokenType?: TokenType | null;
  barColors?: {
    totalInvestment?: string;
    netInvest?: string;
    incomeEstimate?: string;
  };
}

export const BarGraph = ({
  timeframe = 30,
  tokenType,
  barColors = {
    totalInvestment: '#b1d45a',
    netInvest: '#4299e1',
    incomeEstimate: '#ff00c3',
  },
}: BarGraphProps) => {
  const dataset = portfolioInvestments.slice(0, timeframe + 1);

  // Get the icon and label based on the token type
  const getTokenInfo = () => {
    if (!tokenType)
      return { icon: MdOutlineSavings, label: 'Superannuation Projections' };

    const { icon, label } = tokenStyles[tokenType];
    return { icon, label: `${label} Projections` };
  };

  const { label } = getTokenInfo();

  return (
    <ThemeProvider theme={muiTheme}>
      <CssBaseline />
      <Box w="100%" bg="#f7fafc" p={4} borderRadius="md">
        <Text fontSize="lg" fontWeight="medium" textAlign="center">
          {label} over the {timeframe} period
        </Text>
        <BarChart
          dataset={dataset}
          xAxis={[{ scaleType: 'band', dataKey: 'year', label: 'Year' }]}
          yAxis={[
            { id: 'leftAxis', label: 'Investment ($)', position: 'left' },
            {
              id: 'rightAxis',
              label: 'Income ($)',
              position: 'right',
            },
          ]}
          series={[
            {
              dataKey: 'totalInvestment',
              label: 'Total Investments',
              color: barColors.totalInvestment,
              yAxisId: 'leftAxis',
            },
            {
              dataKey: 'netInvest',
              label: 'Net Invest',
              color: barColors.netInvest,
              yAxisId: 'leftAxis',
            },
            {
              dataKey: 'incomeEstimate',
              label: 'Income Estimate',
              color: barColors.incomeEstimate,
              yAxisId: 'rightAxis',
            },
          ]}
          height={380}
          width={800}
          sx={{
            [barElementClasses.root]: { borderRadius: 2 },
            [lineElementClasses.root]: { strokeWidth: 3 },
          }}
        />
      </Box>
    </ThemeProvider>
  );
};
