import { Box, Text } from '@chakra-ui/react';
import { CssBaseline } from '@mui/material';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { BarChart, barElementClasses } from '@mui/x-charts';

import { generateSavingsDataset } from '../../../data/SavingsCalculations.ts';
import { useSavings } from '../../../data/SavingsContext.tsx';
import { formatCurrency } from './InsuranceBarGraph.tsx';

const muiTheme = createTheme({
  palette: {
    mode: 'light',
  },
});

interface BarGraphProps {
  timeframe?: number;
}

export const SavingsBarGraph = ({ timeframe = 30 }: BarGraphProps) => {
  const { inputCards } = useSavings();
  const dataset = generateSavingsDataset(inputCards, timeframe);

  return (
    <ThemeProvider theme={muiTheme}>
      <CssBaseline />
      <Box w="100%" bg="#f7fafc" borderRadius="md">
        <Text fontSize="lg" fontWeight="medium" textAlign="center" pt={4}>
          Savings Projections over the {timeframe} period
        </Text>
        <BarChart
          dataset={dataset}
          xAxis={[
            {
              scaleType: 'band',
              dataKey: 'year',
              label: 'Year',
            },
          ]}
          yAxis={[
            {
              id: 'leftAxis',
              label: 'Balance ($)',
              position: 'left',
              valueFormatter: formatCurrency,
            },
          ]}
          series={[
            {
              dataKey: 'currentSituation',
              label: 'Current Situation',
              color: '#b1d45a', // Green
              yAxisId: 'leftAxis',
            },
            {
              dataKey: 'proposedReturn',
              label: 'Proposed Interest',
              color: '#4299e1', // Blue
              stack: 'proposed',
              yAxisId: 'leftAxis',
            },
            {
              dataKey: 'proposedContributions',
              label: 'Proposed Contributions',
              color: '#f6ad55', // Orange
              stack: 'proposed',
              yAxisId: 'leftAxis',
            },
          ]}
          grid={{ horizontal: true }}
          height={400}
          width={800}
          sx={{
            [barElementClasses.root]: { borderRadius: 2 },
          }}
          slotProps={{
            legend: {
              position: {
                vertical: 'top',
              },
            },
          }}
        />
      </Box>
    </ThemeProvider>
  );
};
