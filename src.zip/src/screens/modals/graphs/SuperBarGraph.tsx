// BarGraph.tsx

import { Box, Text } from '@chakra-ui/react';
import { CssBaseline } from '@mui/material';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { BarChart, barElementClasses } from '@mui/x-charts';

import { formatCurrency } from './InsuranceBarGraph.tsx';
import { generateRealDataset } from '../../../data/SuperannuationCalculations.ts';
import { useSuperannuation } from '../../../data/SuperannuationContext.tsx';

const muiTheme = createTheme({
  palette: {
    mode: 'light',
  },
});

interface BarGraphProps {
  timeframe?: number;
}

export const SuperBarGraph = ({ timeframe = 30 }: BarGraphProps) => {
  const { inputCards } = useSuperannuation();

  const dataset = generateRealDataset(inputCards, timeframe);

  return (
    <ThemeProvider theme={muiTheme}>
      <CssBaseline />
      <Box w="100%" bg="#f7fafc" borderRadius="md">
        <Text fontSize="lg" fontWeight="medium" textAlign="center" pt={4}>
          Superannuation & Tax Projections over the {timeframe} Period
        </Text>
        <BarChart
          dataset={dataset}
          xAxis={[
            {
              scaleType: 'band',
              dataKey: 'year',
              label: 'Year',
            },
          ]}
          yAxis={[
            {
              id: 'leftAxis',
              label: 'Balance ($)',
              position: 'left',
              valueFormatter: formatCurrency,
            },
          ]}
          series={[
            {
              dataKey: 'currentSituation',
              label: 'Current Situation',
              color: '#b1d45a', // Green
              stack: 'total',
              yAxisId: 'leftAxis',
            },
            {
              dataKey: 'proposedConc',
              label: 'Proposed Concessional Contribution',
              color: '#b794f4', // Purple
              stack: 'total',
              yAxisId: 'leftAxis',
            },
            {
              dataKey: 'proposedReturn',
              label: 'Proposed Return',
              color: '#4299e1', // Blue
              stack: 'total',
              yAxisId: 'leftAxis',
            },
            {
              dataKey: 'proposedNonConc',
              label: 'Proposed Non-Concessional Contribution',
              color: '#f6ad55', // Orange
              stack: 'total',
              yAxisId: 'leftAxis',
            },
          ]}
          grid={{ horizontal: true }}
          height={400}
          width={800}
          sx={{
            [barElementClasses.root]: { borderRadius: 2 },
          }}
        />
      </Box>
    </ThemeProvider>
  );
};
