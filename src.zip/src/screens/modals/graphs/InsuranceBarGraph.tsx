import { Box, Text } from '@chakra-ui/react';
import { CssBaseline } from '@mui/material';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { BarChart, barElementClasses } from '@mui/x-charts';

import { generateInsuranceDataset } from '../../../data/InsuranceCalculations';
import { useInsurance } from '../../../data/InsuranceContext';

const muiTheme = createTheme({
  palette: {
    mode: 'light',
  },
});

interface BarGraphProps {
  timeframe?: number;
}

// Format large numbers to $X,XXXk format
export const formatCurrency = (value: number) => {
  if (value >= 1_000_000) {
    return `$${(value / 1_000_000).toLocaleString(undefined, {
      minimumFractionDigits: 0,
      maximumFractionDigits: 1,
    })}M`;
  } else if (value >= 1_000) {
    return `$${(value / 1_000).toLocaleString(undefined, {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    })}k`;
  }
  return `$${value.toLocaleString()}`;
};

export const InsuranceBarGraph = ({ timeframe = 30 }: BarGraphProps) => {
  const { inputCards } = useInsurance();

  const dataset = generateInsuranceDataset(inputCards, timeframe);

  return (
    <ThemeProvider theme={muiTheme}>
      <CssBaseline />
      <Box w="100%" bg="#f7fafc" borderRadius="md">
        <Text fontSize="lg" fontWeight="medium" textAlign="center" pt={4}>
          Insurance Projections over the {timeframe} period
        </Text>
        <BarChart
          dataset={dataset}
          xAxis={[
            {
              scaleType: 'band',
              dataKey: 'year',
              label: 'Year',
            },
          ]}
          yAxis={[
            {
              id: 'leftAxis',
              label: 'Amount ($)',
              position: 'left',
              valueFormatter: formatCurrency,
            },
          ]}
          series={[
            {
              dataKey: 'currentPremiums',
              label: 'Current Plan Premiums',
              color: '#b1d45a',
              stack: 'current',
              yAxisId: 'leftAxis',
            },
            {
              dataKey: 'currentClaims',
              label: 'Current Plan Estimated Benefits',
              color: '#4299e1',
              stack: 'current',
              yAxisId: 'leftAxis',
            },
            {
              dataKey: 'proposedPremiums',
              label: 'Proposed Plan Premiums',
              color: '#ff00c3',
              stack: 'proposed',
              yAxisId: 'leftAxis',
            },
            {
              dataKey: 'proposedClaims',
              label: 'Proposed Plan Estimated Benefits',
              color: '#b794f4',
              stack: 'proposed',
              yAxisId: 'leftAxis',
            },
          ]}
          grid={{ horizontal: true }}
          height={400}
          width={800}
          sx={{
            [barElementClasses.root]: { borderRadius: 2 },
          }}
        />
      </Box>
    </ThemeProvider>
  );
};
