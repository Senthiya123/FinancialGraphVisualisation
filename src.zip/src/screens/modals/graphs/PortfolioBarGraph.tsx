import { Box, Text } from '@chakra-ui/react';
import { CssBaseline } from '@mui/material';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { BarChart, barElementClasses } from '@mui/x-charts';

import { generatePortfolioGrowthDataset } from '../../../data/PortfolioCalculations.ts';
import { usePortfolio } from '../../../data/PortfolioContext.tsx';
import { formatCurrency } from './InsuranceBarGraph.tsx';

const muiTheme = createTheme({
  palette: {
    mode: 'light',
  },
});

interface BarGraphProps {
  timeframe?: number;
}

export const PortfolioBarGraph = ({ timeframe = 30 }: BarGraphProps) => {
  const { inputCards } = usePortfolio();
  const dataset = generatePortfolioGrowthDataset(inputCards, timeframe);

  const processedDataset = dataset.map((item) => ({
    year: item.year,
    contributions: item.proposedContributions,
    returns: item.proposedReturn,
    total:
      item.proposedSituation ??
      item.proposedContributions + item.proposedReturn,
  }));

  return (
    <ThemeProvider theme={muiTheme}>
      <CssBaseline />
      <Box w="100%" bg="#f7fafc" borderRadius="md">
        <Text fontSize="lg" fontWeight="medium" textAlign="center" pt={4}>
          Portfolio Projections over the {timeframe} Period
        </Text>
        <BarChart
          dataset={processedDataset}
          xAxis={[
            {
              scaleType: 'band',
              dataKey: 'year',
              label: 'Year',
            },
          ]}
          yAxis={[
            {
              id: 'leftAxis',
              label: 'Portfolio Value ($)',
              position: 'left',
              valueFormatter: formatCurrency,
            },
          ]}
          series={[
            {
              dataKey: 'contributions',
              label: 'Contributions',
              color: '#b1d45a',
              stack: 'total',
              yAxisId: 'leftAxis',
            },
            {
              dataKey: 'returns',
              label: 'Investment Returns',
              color: '#4299e1',
              stack: 'total',
              yAxisId: 'leftAxis',
            },
          ]}
          grid={{ horizontal: true }}
          height={400}
          width={800}
          sx={{
            [barElementClasses.root]: { borderRadius: 2 },
          }}
          slotProps={{
            legend: {
              position: {
                vertical: 'top',
              },
            },
          }}
        />
      </Box>
    </ThemeProvider>
  );
};
