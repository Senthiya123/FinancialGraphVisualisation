import { Box, Text } from '@chakra-ui/react';
import { CssBaseline } from '@mui/material';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { LineChart, barElementClasses } from '@mui/x-charts';

import { formatCurrency } from './InsuranceBarGraph.tsx';
import { calculateProjectedLoans } from '../../../data/LoansCalculations';
import { useLoans } from '../../../data/LoansContext';

const muiTheme = createTheme({
  palette: {
    mode: 'light',
  },
});

interface BarGraphProps {
  timeframe?: number;
}

export const LoanBarGraph = ({ timeframe = 30 }: BarGraphProps) => {
  const { inputCards, timeframe: contextTimeframe } = useLoans();

  // Use the timeframe from context if provided, otherwise use the prop value
  const effectiveTimeframe = contextTimeframe || timeframe;

  // Generate projection data
  const dataset = calculateProjectedLoans(inputCards, effectiveTimeframe);

  // Filter dataset to only show every 5 years to prevent overcrowding

  return (
    <ThemeProvider theme={muiTheme}>
      <CssBaseline />
      <Box w="100%" bg="#f7fafc" borderRadius="md">
        <Text fontSize="lg" fontWeight="medium" textAlign="center" pt={4}>
          Insurance Projections over the {effectiveTimeframe} Period
        </Text>
        <LineChart
          dataset={dataset}
          xAxis={[
            {
              scaleType: 'band',
              dataKey: 'year',
              label: 'Year',
            },
          ]}
          yAxis={[
            {
              id: 'leftAxis',
              label: 'Loan Balance ($)',
              position: 'left',
              valueFormatter: formatCurrency,
            },
          ]}
          series={[
            {
              dataKey: 'currentSituation',
              label: 'Current Loan',
              color: '#b1d45a',
              yAxisId: 'leftAxis',
              showMark: false,
            },
            {
              dataKey: 'proposedSituation',
              label: 'Proposed Loan',
              color: '#4299e1',
              yAxisId: 'leftAxis',
              showMark: false,
            },
          ]}
          grid={{ horizontal: true }}
          height={400}
          width={800}
          sx={{
            [barElementClasses.root]: { borderRadius: 2 },
          }}
          slotProps={{
            legend: {
              position: {
                vertical: 'top',
                horizontal: 'center',
              },
            },
          }}
        />
      </Box>
    </ThemeProvider>
  );
};
