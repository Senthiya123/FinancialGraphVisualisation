import { type SystemStyleObject } from '@chakra-ui/react';

export const HeaderSx: SystemStyleObject = {
  width: '100%',
  height: '70px',
  margin: '0 0 68px',
  padding: '13px 62px 11px 70px',
  borderRadius: '4px',
  boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.04)',
  border: 'solid 1px #e2e8f0',
  backgroundColor: '#fff',
};

export const TabSx = {
  fontWeight: 'semibold',
  color: '#a0aec0',
  _selected: {
    color: '#b1d45a',
  },
};
