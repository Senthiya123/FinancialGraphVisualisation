import { type SystemStyleObject } from '@chakra-ui/react';

export const ContentContainerSx: SystemStyleObject = {
  width: '90vw',
  maxWidth: '1500px',
  height: '767px',
  margin: '68px 70px 12px',
  padding: '44px 40px 23.6px 30px',
  borderRadius: '28px',
  boxShadow: '0 1px 26px 0 rgba(81, 126, 200, 0.21)',
  border: 'solid 1px #e2e8f0',
  backgroundColor: '#fff',
};

export const FooterText: SystemStyleObject = {
  color: '#a0aec0',
  fontSize: 'sm',
};
