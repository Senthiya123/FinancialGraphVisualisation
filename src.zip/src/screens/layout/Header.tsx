import { ChevronDownIcon, Tab, TabList, Tabs } from '@chakra-ui/icons';
import {
  Avatar,
  Box,
  HStack,
  Icon,
  Menu,
  MenuButton,
  MenuItem,
  MenuList,
  Text,
} from '@chakra-ui/react';
import { GiGreenhouse } from 'react-icons/gi';

import { HeaderSx, TabSx } from './Header.styles.tsx';

export const Header = () => {
  return (
    <Box sx={HeaderSx}>
      <HStack justify="space-between">
        <HStack gap={10}>
          <HStack gap={3}>
            <Icon as={GiGreenhouse} boxSize={8} color="#b1d45a" />
            <Text fontSize="xl" color="#58585a">
              <b>Insight</b> Wealth Planning
            </Text>
          </HStack>

          {/* Tabs */}
          <Tabs size="md" variant="unstyled" defaultIndex={1}>
            <TabList>
              <Tab sx={TabSx}>Foundations</Tab>
              <Tab sx={TabSx}>Goals</Tab>
            </TabList>
          </Tabs>
        </HStack>
        <HStack>
          <Text>Tabitha Tworek</Text>
          <Menu>
            <MenuButton as={Box} cursor="pointer">
              <HStack>
                <Avatar size="sm" name="Tabitha Tworek" src="/avatar.png" />
                <Icon as={ChevronDownIcon} />
              </HStack>
            </MenuButton>
            <MenuList>
              <MenuItem>Log out</MenuItem>
            </MenuList>
          </Menu>
        </HStack>
      </HStack>
    </Box>
  );
};
