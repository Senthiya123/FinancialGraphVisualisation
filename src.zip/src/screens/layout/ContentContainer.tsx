import { Box, Flex, Text, VStack } from '@chakra-ui/react';
import { type ReactNode } from 'react';

import { ContentContainerSx, FooterText } from './ContentContainer.styles.ts';

interface ContentContainerProps {
  children: ReactNode;
}

export const ContentContainer = ({ children }: ContentContainerProps) => {
  return (
    <Flex justifyContent="center" alignItems="center">
      <VStack>
        <Box sx={ContentContainerSx}>{children}</Box>
        <Text sx={FooterText}>
          <b>Insight</b> Wealth Planning Quick Modelling / copyright / legal
          links / version#
        </Text>
      </VStack>
    </Flex>
  );
};
