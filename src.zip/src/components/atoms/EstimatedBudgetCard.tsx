import { Box, Divider, Text, VStack } from '@chakra-ui/react';

import {
  EstimatedBudgetAmountSx,
  EstimatedBudgetCardSx,
  EstimatedBudgetFooterSx,
  EstimatedBudgetHeaderSx,
} from './EstimatedBudgetCard.styles.ts';

export const EstimatedBudgetCard = () => {
  return (
    <Box sx={EstimatedBudgetCardSx}>
      <VStack w="100%" alignItems="flex-start">
        <VStack sx={EstimatedBudgetHeaderSx}>
          <Text sx={EstimatedBudgetAmountSx}>ESTIMATED WEEKLY BUDGET</Text>
          <Text fontSize="4xl" color="white">
            $1,321
          </Text>
        </VStack>
        <Divider />
        <Text sx={EstimatedBudgetFooterSx}>WEEKLY COST: $284</Text>
      </VStack>
    </Box>
  );
};
