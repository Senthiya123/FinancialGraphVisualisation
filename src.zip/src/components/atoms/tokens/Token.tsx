import { Box, Text, VStack } from '@chakra-ui/react';
import { useCallback } from 'react';
import { useDrag } from 'react-dnd';
import { type IconType } from 'react-icons';
import {
  MdCheckCircleOutline,
  MdOutlineCottage,
  MdOutlineGppGood,
  MdOutlineMonetizationOn,
  MdOutlineSavings,
  MdOutlineTrendingUp,
} from 'react-icons/md';

import { TokenPlaceholderSx, TokenSx } from './Token.styles';

export type TokenType =
  | 'insurance'
  | 'super'
  | 'savings'
  | 'loans'
  | 'portfolio';

interface TokenProps {
  type: TokenType;
  isInDropzone: boolean;
}

export const tokenStyles: Record<
  TokenType,
  { bg: string; border: string; label: string; icon: IconType }
> = {
  insurance: {
    bg: '#5ad4b6',
    border: '#5fe7c5',
    label: 'Insurance',
    icon: MdOutlineGppGood,
  },
  super: {
    bg: '#5ab8d4',
    border: '#66d1f1',
    label: 'Super/Tax',
    icon: MdOutlineSavings,
  },
  savings: {
    bg: '#e684d1',
    border: '#eca7dd',
    label: 'Savings',
    icon: MdOutlineMonetizationOn,
  },
  loans: {
    bg: '#d4cc5a',
    border: '#e4dd81',
    label: 'Loans',
    icon: MdOutlineCottage,
  },
  portfolio: {
    bg: '#d4a35a',
    border: '#ecc386',
    label: 'Portfolio',
    icon: MdOutlineTrendingUp,
  },
};

const ITEM_TYPE = 'TOKEN';

export const Token = ({ type, isInDropzone }: TokenProps) => {
  const { bg, border, label, icon: Icon } = tokenStyles[type];

  const [{ isDragging }, drag] = useDrag(() => ({
    type: ITEM_TYPE,
    item: { type }, // Include the token type in the dragged item
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
    canDrag: !isInDropzone, // Only allow dragging if the token is not already in the dropzone
  }));

  const setRef = useCallback(
    (node: HTMLDivElement | null) => {
      if (node) drag(node);
    },
    [drag],
  );

  return (
    <Box position="relative" width="100px" height="100px">
      {/* Always show the placeholder if the token is in dropzone or being dragged */}
      {(isInDropzone || isDragging) && (
        <Box sx={TokenPlaceholderSx}>
          {isInDropzone && (
            <Box
              position="absolute"
              top="0px"
              right="0px"
              zIndex="1"
              bg={'white'}
              borderRadius={'full'}
            >
              <MdCheckCircleOutline size="24px" color="#ff01c3" />
            </Box>
          )}
          <VStack spacing="4px" align="center">
            <Icon size="38px" color="#cbd5e0" />
            <Text
              fontSize="xs"
              fontWeight="bold"
              color="#cbd5e0"
              textAlign="center"
            >
              {label}
            </Text>
          </VStack>
        </Box>
      )}

      {/* Only show the actual token if it's not in the dropzone */}
      {!isInDropzone && (
        <Box
          ref={setRef}
          border={`5px solid ${border}`}
          bg={bg}
          position="absolute"
          top="0"
          left="0"
          sx={{
            ...TokenSx,
            opacity: isDragging ? 0 : 1,
            cursor: isDragging ? 'grabbing' : 'grab',
            transform: isDragging ? 'scale(1.05)' : 'scale(1)',
            zIndex: isDragging ? 2 : 1,
          }}
        >
          <VStack spacing="4px" align="center">
            <Icon size="38px" color="white" />
            <Text
              fontSize="xs"
              fontWeight="bold"
              color="white"
              textAlign="center"
            >
              {label}
            </Text>
          </VStack>
        </Box>
      )}
    </Box>
  );
};
