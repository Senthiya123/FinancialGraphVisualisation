import { Box } from '@chakra-ui/react';
import { useCallback } from 'react';
import { useDrag } from 'react-dnd';

import { type TokenType, tokenStyles } from './Token';

// Define the shape of the drop result object
interface DropResult {
  name?: string;
}

interface DroppedTokenProps {
  type: TokenType;
  onRemove: () => void;
}

export const DroppedToken = ({ type, onRemove }: DroppedTokenProps) => {
  const { bg, border, icon: Icon } = tokenStyles[type];

  const [{ isDragging }, drag] = useDrag(() => ({
    type: 'DROPPED_TOKEN',
    item: { type },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
    end: (_, monitor) => {
      // Only call onRemove if not dropped back in the dropzone
      const dropResult = monitor.getDropResult<DropResult>();
      if (!dropResult || dropResult.name !== 'Dropzone') {
        onRemove();
      }
    },
  }));

  const setRef = useCallback(
    (node: HTMLDivElement | null) => {
      if (node) drag(node);
    },
    [drag],
  );

  return (
    <Box
      ref={setRef}
      borderRadius="full"
      display="flex"
      justifyContent="center"
      alignItems="center"
      width="75px"
      height="75px"
    >
      <Box
        border={`5px solid ${border}`}
        bg={bg}
        borderRadius="full"
        width="60px"
        height="60px"
        display="flex"
        justifyContent="center"
        alignItems="center"
        opacity={isDragging ? 0.5 : 1}
        cursor={isDragging ? 'grabbing' : 'grab'}
        boxShadow="0 2px 7px 0 rgba(0, 0, 0, 0.5), inset -1px 1.2px 0 0 rgba(0, 0, 0, 0.25)"
        transition="all 0.2s ease-out"
        overflow="visible" // Prevents the shadow from being clipped
      >
        <Icon size="30px" color="white" />
      </Box>
    </Box>
  );
};
