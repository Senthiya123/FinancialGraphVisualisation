import { type SystemStyleObject } from '@chakra-ui/react';

export const ProposedBudgetCardSx: SystemStyleObject = {
  bg: '#4299e1',
  borderRadius: '6px',
  width: '225px',
  padding: 5,
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
};

export const ProposedBudgetHeaderSx: SystemStyleObject = {
  alignItems: 'flex-start',
  width: '100%',
  gap: 0,
};

export const ProposedBudgetAmountSx: SystemStyleObject = {
  fontSize: 'xs',
  color: 'white',
  fontWeight: 'semibold',
};

export const ProposedBudgetFooterSx: SystemStyleObject = {
  fontSize: 'sm',
  color: 'white',
  fontWeight: 'semibold',
};
