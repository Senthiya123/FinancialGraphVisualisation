import { type SystemStyleObject } from '@chakra-ui/react';

export const TokenSx: SystemStyleObject = {
  width: '100px',
  height: '100px',
  borderRadius: 'full',
  boxShadow: 'inset -1px 3px 0 0 rgba(0, 0, 0, 0.25)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  cursor: 'grab',
  zIndex: 1,
  userSelect: 'none',
  transition: 'transform 0.2s ease',
};

export const TokenPlaceholderSx: SystemStyleObject = {
  width: '100px',
  height: '100px',
  borderRadius: 'full',
  border: '3px dotted #a0aec0',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  position: 'absolute',
  top: '0',
  left: '0',
};
