import { type SystemStyleObject } from '@chakra-ui/react';

export const EstimatedBudgetCardSx: SystemStyleObject = {
  bg: '#b1d45a',
  borderRadius: '6px',
  width: '225px',
  padding: 5,
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
};

export const EstimatedBudgetHeaderSx: SystemStyleObject = {
  alignItems: 'flex-start',
  width: '100%',
  gap: 0,
};

export const EstimatedBudgetAmountSx: SystemStyleObject = {
  fontSize: 'xs',
  color: 'white',
  fontWeight: 'semibold',
};

export const EstimatedBudgetFooterSx: SystemStyleObject = {
  fontSize: 'xs',
  color: 'white',
  py: '3px',
  fontWeight: 'semibold',
};
