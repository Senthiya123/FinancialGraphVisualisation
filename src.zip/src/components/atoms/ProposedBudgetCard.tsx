import { Box, Divider, Text, VStack } from '@chakra-ui/react';
import { useMemo } from 'react';

import {
  ProposedBudgetAmountSx,
  ProposedBudgetCardSx,
  ProposedBudgetFooterSx,
  ProposedBudgetHeaderSx,
} from './tokens/ProposedBudgetCard.styles.ts';
import { type TokenType } from './tokens/Token.tsx';
import { calculateMonthlyCostDifference } from '../../data/InsuranceCalculations.ts';
import { useInsurance } from '../../data/InsuranceContext.tsx';
import { calculateMonthlyInvestmentDifference } from '../../data/PortfolioCalculations.ts';
import { usePortfolio } from '../../data/PortfolioContext.tsx';
import { calculateWeeklyCost } from '../../data/SuperannuationCalculations.ts';
import { useSuperannuation } from '../../data/SuperannuationContext.tsx';
import { useTimeframe } from '../../data/TimeframeContext.tsx';

interface ProposedBudgetCardProps {
  droppedTokensArray: TokenType[];
}

export const ProposedBudgetCard = ({
  droppedTokensArray,
}: ProposedBudgetCardProps) => {
  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('en-AU', {
      style: 'currency',
      currency: 'AUD',
      maximumFractionDigits: 0,
    }).format(value);

  const { timeframe } = useTimeframe();
  const { inputCards: superInputCards } = useSuperannuation();
  const { inputCards: portfolioInputCards } = usePortfolio();
  const { inputCards: insuranceInputCards } = useInsurance();

  const {
    super_cost,
    portfolio_cost,
    weeklyFees,
    totalWeeklyCost,
    totalWeeklyBudget,
  } = useMemo(() => {
    let super_cost = 0;
    let portfolio_cost = 0;

    if (droppedTokensArray.includes('super')) {
      super_cost = calculateWeeklyCost(superInputCards);
    }

    if (droppedTokensArray.includes('portfolio')) {
      portfolio_cost = Math.floor(
        calculateMonthlyInvestmentDifference(portfolioInputCards) / 4,
      );
    }

    const insuranceWeekly = Math.floor(
      calculateMonthlyCostDifference(insuranceInputCards) / 4,
    );

    const weeklyFees =
      super_cost +
      portfolio_cost +
      insuranceWeekly +
      32 * droppedTokensArray.length; // add arbitrary fees for every token
    const totalWeeklyCost = 284 + super_cost + portfolio_cost + weeklyFees;
    const totalWeeklyBudget = 1312 + totalWeeklyCost;

    return {
      super_cost,
      portfolio_cost,
      weeklyFees,
      totalWeeklyCost,
      totalWeeklyBudget,
    };
  }, [
    droppedTokensArray,
    superInputCards,
    portfolioInputCards,
    insuranceInputCards,
    timeframe,
  ]);

  return (
    <Box
      sx={ProposedBudgetCardSx}
      visibility={droppedTokensArray.length ? 'visible' : 'hidden'}
    >
      <VStack w="100%" alignItems="flex-start">
        <VStack sx={ProposedBudgetHeaderSx}>
          <Text sx={ProposedBudgetAmountSx}>PROPOSED WEEKLY BUDGET</Text>
          <Text fontSize="4xl" color="white">
            {formatCurrency(totalWeeklyBudget)}
          </Text>
        </VStack>
        <Divider />
        <VStack gap={0} width={'100%'} alignItems="flex-start">
          <Text sx={ProposedBudgetAmountSx}>
            SUPERANNUATION: {formatCurrency(super_cost)}
          </Text>
          <Text sx={ProposedBudgetAmountSx}>
            PORTFOLIO: {formatCurrency(portfolio_cost)}
          </Text>
          <Text sx={ProposedBudgetAmountSx}>
            WEEKLY FEES: {formatCurrency(weeklyFees)}
          </Text>
        </VStack>
        <Divider />
        <VStack gap={0} width={'100%'} alignItems="flex-start">
          <Text sx={ProposedBudgetFooterSx}>
            WEEKLY COST: {formatCurrency(totalWeeklyCost)}
          </Text>
        </VStack>
      </VStack>
    </Box>
  );
};
