import {
  Box,
  Divider,
  Flex,
  Slider,
  SliderFilledTrack,
  SliderThumb,
  SliderTrack,
  Text,
  VStack,
} from '@chakra-ui/react';
import { useEffect } from 'react';

import { useTimeframe } from '../../data/TimeframeContext.tsx';

interface TimeframeSliderProps {
  value?: number;
  onChange?: (value: number) => void;
}

export const TimeframeSlider = ({ value, onChange }: TimeframeSliderProps) => {
  // Use external value if provided, otherwise default to 30
  const { timeframe, setTimeframe } = useTimeframe();

  // Sync internal state with external value when it changes
  useEffect(() => {
    if (value !== undefined) {
      setTimeframe(value);
    }
  }, [value]);

  const handleChange = (newValue: number) => {
    setTimeframe(newValue);
    if (onChange) {
      onChange(newValue);
    }
  };

  return (
    <VStack w={'100%'}>
      <Box display="grid" height="6.8px" width="100%">
        <Flex width="100%" height="100%" position="relative">
          {[0, 25, 50, 75, 100].map((position) => (
            <Box
              key={position}
              position="absolute"
              left={`${position}%`}
              height="100%"
            >
              <Divider
                orientation="vertical"
                borderColor={'#cbd5e0'}
                borderWidth={'1px'}
              />
            </Box>
          ))}
        </Flex>
      </Box>
      <Slider
        aria-label="timeframe-slider"
        value={timeframe}
        onChange={handleChange}
        min={0}
        max={60}
        step={1}
        size={'md'}
      >
        <SliderTrack bg={'#d8d8d8'}>
          <SliderFilledTrack bg="#b1d45a" />
        </SliderTrack>
        <SliderThumb />
      </Slider>
      <Text fontSize="sm" color="#718096">
        Timeframe: <strong>{timeframe} years</strong>
      </Text>
    </VStack>
  );
};
