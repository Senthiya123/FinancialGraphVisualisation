import { VStack } from '@chakra-ui/react';

import { Token, type TokenType } from './atoms/tokens/Token.tsx';

interface TokenColumnProps {
  droppedTokenTypes: Set<TokenType>;
}

export const TokenColumn = ({ droppedTokenTypes }: TokenColumnProps) => {
  const tokenTypes: TokenType[] = [
    'insurance',
    'super',
    'savings',
    'loans',
    'portfolio',
  ];

  return (
    <VStack gap={'10px'}>
      {tokenTypes.map((type) => (
        <Token
          key={type}
          type={type}
          isInDropzone={droppedTokenTypes.has(type)}
        />
      ))}
    </VStack>
  );
};
