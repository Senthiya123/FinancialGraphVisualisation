import { Box, Text, Tooltip, VStack } from '@chakra-ui/react';
import { useCallback, useMemo } from 'react';
import { useDrop } from 'react-dnd';

// Import contexts and calculation functions
import { calculateOutOfPocketDifference } from '../data/InsuranceCalculations.ts';
import { useInsurance } from '../data/InsuranceContext.tsx';
import { calculateInterestSaved } from '../data/LoansCalculations.ts';
import { useLoans } from '../data/LoansContext.tsx';
import { calculateProjectedPortfolioValue } from '../data/PortfolioCalculations.ts';
import { usePortfolio } from '../data/PortfolioContext.tsx';
import { calculateProjectedSavings } from '../data/SavingsCalculations.ts';
import { useSavings } from '../data/SavingsContext.tsx';
import { calculateProjectedBalance } from '../data/SuperannuationCalculations.ts';
import { useSuperannuation } from '../data/SuperannuationContext.tsx';
import { useTimeframe } from '../data/TimeframeContext.tsx';
import { DroppedToken } from './atoms/tokens/DroppedToken';
import { type TokenType, tokenStyles } from './atoms/tokens/Token';
import { DropzoneValues } from '../screens/modals/components/DropzoneValues.tsx';

interface DropzoneProps {
  onTokenDrop: (tokenType: TokenType) => void;
  droppedTokens: TokenType[];
  onTokenRemove: (tokenType: TokenType) => void;
  onTokenClick: (tokenType: TokenType) => void;
}

const Dropzone = ({
  onTokenDrop,
  droppedTokens,
  onTokenRemove,
  onTokenClick,
}: DropzoneProps) => {
  const { timeframe } = useTimeframe();

  // Insurance calculations
  const { inputCards: insuranceCards } = useInsurance();
  const insuranceValue = useMemo(() => {
    const outOfPocketSavings = calculateOutOfPocketDifference(insuranceCards);
    return outOfPocketSavings.valueOf();
  }, [insuranceCards]);

  // Super calculations
  const { inputCards: superCards } = useSuperannuation();
  const superValue = useMemo(() => {
    const projectedBalances = calculateProjectedBalance(superCards, timeframe);
    return projectedBalances.proposed;
  }, [superCards, timeframe]);

  // Savings calculations
  const { inputCards: savingsCards } = useSavings();
  const savingsValue = useMemo(() => {
    const projectedSavings = calculateProjectedSavings(savingsCards, timeframe);
    return projectedSavings.proposed;
  }, [savingsCards, timeframe]);

  // Loans calculations
  const { inputCards: loanCards } = useLoans();
  const loanValue = useMemo(() => {
    return calculateInterestSaved(loanCards);
  }, [loanCards]);

  // Portfolio calculations
  const { inputCards: portfolioCards } = usePortfolio();
  const portfolioValue = useMemo(() => {
    const projected = calculateProjectedPortfolioValue(
      portfolioCards,
      timeframe,
    );
    return projected.proposed;
  }, [portfolioCards, timeframe]);

  // Current value calculation
  const currentValue = useMemo(() => {
    return Math.floor(2979954 / 30) * timeframe;
  }, [timeframe]);

  // Calculate the token values for calculating ring sizes
  const tokenValues = useMemo(() => {
    return {
      insurance: insuranceValue,
      super: superValue,
      savings: savingsValue,
      loans: loanValue,
      portfolio: portfolioValue,
    };
  }, [insuranceValue, superValue, savingsValue, loanValue, portfolioValue]);

  // Calculate proposed value based on dropped tokens
  const proposedValue = useMemo(() => {
    let total = 0;

    droppedTokens.forEach((token) => {
      total += tokenValues[token] || 0;
    });

    return total;
  }, [droppedTokens, tokenValues]);

  // Use the useDrop hook to make this component a drop target
  const [{ isOver, canDrop }, drop] = useDrop(() => ({
    // Accept both regular tokens and dropped tokens
    accept: ['TOKEN', 'DROPPED_TOKEN'],
    drop: (item: { type: TokenType }) => {
      handleTokenDrop(item.type);
      return { name: 'Dropzone' };
    },
    collect: (monitor) => ({
      isOver: monitor.isOver(),
      canDrop: monitor.canDrop(),
    }),
  }));

  // Create a ref callback that can be safely passed to the Box component
  const setDropRef = useCallback(
    (node: HTMLDivElement | null) => {
      if (node) drop(node);
    },
    [drop],
  );

  // Trigger ripple effect when token is dropped
  const handleTokenDrop = useCallback(
    (tokenType: TokenType) => {
      // Call the parent component's handler
      onTokenDrop(tokenType);
    },
    [onTokenDrop],
  );

  // Format currency value
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-AU', {
      style: 'currency',
      currency: 'AUD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  // Get display name for token type
  const getTokenDisplayName = (tokenType: TokenType) => {
    const displayNames = {
      insurance: 'Insurance',
      super: 'Superannuation',
      savings: 'Savings',
      loans: 'Loans',
      portfolio: 'Portfolio',
    };
    return displayNames[tokenType] || tokenType;
  };

  // Position tokens in a circular arrangement
  const positionTokens = () => {
    const centerX = 268; // Center X of the dropzone (536/2)
    const centerY = 268; // Center Y of the dropzone (536/2)
    const radius = 150; // Distance from center

    return droppedTokens.map((tokenType, index) => {
      // Calculate position in a circle
      const angle = (2 * Math.PI * index) / Math.max(droppedTokens.length, 1);
      const x = centerX + radius * Math.cos(angle) - 37.5;
      const y = centerY + radius * Math.sin(angle) - 37.5;

      const tooltipLabel = (
        <VStack align="start" spacing={0}>
          <>
            <Text>{getTokenDisplayName(tokenType)}</Text>
            <Text>
              Proposed strategy benefit generates{' '}
              {formatCurrency(tokenValues[tokenType] || 0)}
            </Text>
          </>
        </VStack>
      );
      return (
        <Tooltip
          key={`${tokenType}-${index}`}
          label={tooltipLabel}
          placement="auto"
          hasArrow
          bg="gray.700"
          color="white"
          borderRadius="md"
          px={3}
          py={2}
        >
          <Box
            position="absolute"
            left={`${x}px`}
            top={`${y}px`}
            zIndex={2}
            onClick={() => onTokenClick(tokenType)}
            cursor="pointer"
          >
            <DroppedToken
              type={tokenType}
              onRemove={() => onTokenRemove(tokenType)}
            />
          </Box>
        </Tooltip>
      );
    });
  };

  // Calculate ring width based on token value proportion
  const calculateRingWidth = (tokenType: TokenType) => {
    const tokenValue = tokenValues[tokenType];
    const totalValue = proposedValue || 1; // Avoid division by zero

    // Calculate proportion of total (as a percentage)
    const proportion = tokenValue / totalValue;

    // Scale to a reasonable width range (min 5px, max 30px)
    const minWidth = 8;
    const maxWidth = 50;

    return Math.max(minWidth, Math.min(maxWidth, proportion * 100));
  };

  return (
    <Box
      ref={setDropRef}
      borderRadius="full"
      bg="#f7fafc"
      border={isOver ? '2px solid #b1d45a' : '1px dashed #e2e8f0'}
      width="536px"
      height="536px"
      display="flex"
      justifyContent="center"
      alignItems="center"
      position="relative"
      transition="all 0.2s ease"
      _hover={{
        borderColor: canDrop ? '#b1d45a' : '#e2e8f0',
        boxShadow: canDrop ? '0 0 10px rgba(177, 212, 90, 0.3)' : 'none',
      }}
    >
      {/* Display tokens in the drop zone */}
      {positionTokens()}

      {/* Display value-proportional rings */}
      {droppedTokens.map((tokenType, index) => {
        const ringWidth = calculateRingWidth(tokenType);
        const baseSize = 317;
        const previousRingsWidth = droppedTokens
          .slice(0, index)
          .reduce((total, token) => total + calculateRingWidth(token) * 2, 0);

        const size = baseSize + previousRingsWidth + ringWidth * 2;
        const color = tokenStyles[tokenType]?.bg || '#CBD5E0';

        return (
          <Box
            key={`ring-${tokenType}-${index}`}
            position="absolute"
            width={`${size}px`}
            height={`${size}px`}
            borderRadius="full"
            border={`${ringWidth}px solid ${color}`}
            top={`calc(50% - ${size / 2}px)`}
            left={`calc(50% - ${size / 2}px)`}
            zIndex={0}
            pointerEvents="none"
            transition="all 0.3s ease-in-out"
          />
        );
      })}

      <Box
        borderRadius="full"
        bg="#b1d45a"
        border="solid 1px #e2e8f0"
        width="318px"
        height="318px"
        display="flex"
        justifyContent="center"
        alignItems="center"
      >
        <DropzoneValues
          currentValue={currentValue}
          proposedValue={proposedValue}
          hasDroppedTokens={droppedTokens.length > 0}
        />
      </Box>
      {/* Text that follows the curve of the outer circle */}
      <Box
        position="absolute"
        width="100%"
        height="100%"
        top="0"
        left="0"
        zIndex={2}
        pointerEvents="none"
      >
        <svg width="100%" height="100%" viewBox="0 0 536 536">
          <defs>
            <path
              id="circlePath"
              d="M 268 60 A 208 208 0 0 0 268 476 A 208 208 0 0 0 268 60"
              fill="none"
            />
          </defs>
          <text
            fill={isOver ? '#b1d45a' : '#ccd6e0'}
            fontSize="16"
            fontWeight="bold"
          >
            <textPath
              xlinkHref="#circlePath"
              startOffset="50%"
              textAnchor="middle"
            >
              {isOver ? 'Release to drop token' : 'Drop your tokens here.'}
            </textPath>
          </text>
        </svg>
      </Box>
    </Box>
  );
};

export default Dropzone;
