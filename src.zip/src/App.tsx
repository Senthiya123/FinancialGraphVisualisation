import './App.css';
import { GameOfMoney } from './screens/GameOfMoney.tsx';
import { ContentContainer } from './screens/layout/ContentContainer.tsx';
import { Header } from './screens/layout/Header.tsx';

function App() {
  return (
    <>
      <Header />
      <ContentContainer>
        <GameOfMoney />
      </ContentContainer>
    </>
  );
}

export default App;
