// src/theme.ts
import { extendTheme } from '@chakra-ui/react';

export const theme = extendTheme({
  styles: {
    global: {
      body: {
        bg: '#f7fafc',
        marginBottom: '163px',
      },
    },
  },
});
